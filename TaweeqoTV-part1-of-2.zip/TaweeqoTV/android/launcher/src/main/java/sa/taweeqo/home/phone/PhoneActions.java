package sa.taweeqo.home.phone;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import sa.taweeqo.home.BuildConfig;
import sa.taweeqo.home.PhoneApps;
import sa.taweeqo.home.RemoteNav;
import sa.taweeqo.home.tilawah.NowPlaying;
import sa.taweeqo.home.tilawah.PhoneBridge;

/**
 * What the phone does on the TV, on this TV's own screens and through the same code as the TV's settings:
 *  - keys: delivered to our own screen that is in front (Android allows an app to send keys to its own windows only); volume, mute, play/pause
 *    and home go through the system's own calls. Up/down/left/right/OK/back while another app is in front are refused ("other_app").
 *  - text: into the focused text field of our own screen, or as a task when «المهام» is open; otherwise copied to the TV's clipboard.
 *  - settings: the city and the home cards through the screensaver app's provider (SaverReceiver.set), the adhan and the Quran player
 *    through tilawah.PhoneBridge (the same code as optimize/music.sh).
 */
final class PhoneActions implements Actions {
    private static final Uri SAVER = Uri.parse("content://sa.taweeqo.screensaver.config");

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());

    PhoneActions(Context app) { this.app = app.getApplicationContext(); }

    // ---- keys

    @Override public Result key(String key) {
        // «إيقاف الأذان بأي زر»: the phone's key stops a playing adhan first and is used up, as the TV's own remote does (volume keys excepted)
        if (RemoteNav.stopsAdhan(key, NowPlaying.adhanLive(), NowPlaying.adhanStopKey(app))) {
            NowPlaying.stopAdhan(app);
            return Result.ok("done");
        }
        AudioManager audio = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        switch (key) {
            case "vol_up": audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); sa.taweeqo.home.MuteKeep.ours(app, "phone_vol_up"); return Result.ok("done");
            case "vol_down": audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); sa.taweeqo.home.MuteKeep.ours(app, "phone_vol_down"); return Result.ok("done");
            case "mute": audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI); sa.taweeqo.home.MuteKeep.ours(app, "phone_mute_toggle"); return Result.ok("done");
            case "home":
                if (PhoneApps.keysEverywhere() && RemoteNav.DONE.equals(PhoneApps.pressKey("home"))) return Result.ok("done");   // the service's Home: right from any app
                try {
                    app.startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    return Result.ok("done");
                } catch (RuntimeException e) {
                    return Result.fail("failed");
                }
            case "play_pause":
                if (PhoneBridge.pauseOurs(app)) return Result.ok("done");
                audio.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
                audio.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
                return Result.ok("sent");   // to whatever app is playing; the system decides
            default:
                break;
        }
        final int code;
        switch (key) {
            case "up": code = KeyEvent.KEYCODE_DPAD_UP; break;
            case "down": code = KeyEvent.KEYCODE_DPAD_DOWN; break;
            case "left": code = KeyEvent.KEYCODE_DPAD_LEFT; break;
            case "right": code = KeyEvent.KEYCODE_DPAD_RIGHT; break;
            case "ok": code = KeyEvent.KEYCODE_DPAD_CENTER; break;
            case "back": code = KeyEvent.KEYCODE_BACK; break;
            default: return Result.fail("failed");
        }
        final Activity a = Foreground.current();
        if (a == null) {   // no screen of ours in front: Android lets an app send keys only to its own windows, so one of our accessibility services presses it when it is on
            String r = PhoneApps.pressKey(key);
            if (RemoteNav.DONE.equals(r)) return Result.ok("done");
            if (RemoteNav.LIMITED.equals(r)) return Result.fail("other_app_limited");   // the service is on but the app has nothing to move or click, or this Android needs the other service
            if (!RemoteNav.FAILED.equals(r) && sa.taweeqo.home.A11yHeal.stuck(app)) return Result.fail("a11y_stuck");   // on in the TV's list but not running (after an update): say so, not «turn it on»
            return Result.fail(RemoteNav.FAILED.equals(r) ? "failed" : "other_app");
        }
        if (a instanceof PrivateScreen) return Result.fail("private_screen");
        main.post(new Runnable() {
            @Override public void run() {
                long t = SystemClock.uptimeMillis();
                a.dispatchKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0));
                a.dispatchKeyEvent(new KeyEvent(t, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, code, 0));
            }
        });
        return Result.ok("done");
    }

    // ---- text

    /** A task with a time, from the phone's new-task form: added to «المهام» through the screensaver app, whatever is on the TV's screen; «task» or «failed» (full list, empty text, an older screensaver app). */
    @Override public Result text(String text, String mode, boolean search, long due) {
        android.content.ContentValues v = new android.content.ContentValues();
        v.put("t", text);
        v.put("due", due);
        v.put("bf", 0);
        try {
            boolean ok = app.getContentResolver().insert(android.net.Uri.parse("content://sa.taweeqo.screensaver.config/tasks"), v) != null;
            if (ok) sa.taweeqo.home.ReminderScheduler.schedule(app);
            return ok ? Result.ok("task") : Result.fail("failed");
        } catch (RuntimeException e) {
            return Result.fail("failed");
        }
    }

    @Override public Result text(final String text, String mode, boolean search) {
        // the typing log (tag UrTVType): fixed words and the length only, never the text or a package name
        android.util.Log.i("UrTVType", "text request: mode=" + ("append".equals(mode) ? "append" : "replace") + " search=" + search + " len=" + (text == null ? 0 : text.length()));
        android.util.Log.i("UrTVType", Foreground.current() == null ? "foreground=other" : "foreground=own");
        final boolean[] otherNoField = {false};
        if (Foreground.current() == null) {   // another app in front: through the accessibility service, when the owner turned it on
            String r = PhoneApps.typeText(app, text, "append".equals(mode), search);
            switch (r) {
                case "typed_other": case "typed_other_nosearch": case "searched": return Result.ok(r);
                case "no_field": otherNoField[0] = true; break;   // the app has no text field on screen: the text goes to the TV's clipboard, as it always did
                case "service_off": return Result.fail(sa.taweeqo.home.A11yHeal.stuck(app) ? "a11y_stuck" : r);
                default: return Result.fail(r);   // locked, password_field, failed
            }
        }
        FutureTask<String> job = new FutureTask<>(new java.util.concurrent.Callable<String>() {
            @Override public String call() {
                Activity a = Foreground.current();
                if (a != null && !(a instanceof PrivateScreen)) {
                    if (a instanceof TextTarget && ((TextTarget) a).acceptText(text)) return "task";
                    View f = a.getCurrentFocus();
                    if (f instanceof EditText) {
                        EditText e = (EditText) f;
                        Editable ed = e.getText();
                        int s = Math.max(0, e.getSelectionStart()), t = Math.max(0, e.getSelectionEnd());
                        ed.replace(Math.min(s, t), Math.max(s, t), text);
                        return "typed";
                    }
                }
                try {
                    ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("urtv", text));
                    return "copied";
                } catch (RuntimeException e) {
                    return null;
                }
            }
        });
        main.post(job);
        try {
            String r = job.get(2, TimeUnit.SECONDS);
            return r == null ? Result.fail("failed") : Result.ok(otherNoField[0] && "copied".equals(r) ? "copied_other" : r);
        } catch (java.util.concurrent.TimeoutException e) {
            // 4.3 S7: a busy main thread would still run it later, after the phone was told «failed» and sent it again: typed twice.
            // Cancelled without interrupting: if it has not started it never will; if it is running it finishes once
            job.cancel(false);
            return Result.fail("failed");
        } catch (Exception e) {
            return Result.fail("failed");
        }
    }

    // ---- state and settings

    private Bundle saver(String method, String arg, Bundle extras) {
        try {
            return app.getContentResolver().call(SAVER, method, arg, extras);
        } catch (RuntimeException e) {
            return null;   // the screensaver app is missing, older, or not signed with our key
        }
    }

    /** «اللغة» as the screensaver holds it now (no cached copy: the page asked right after its link was pressed has the new one); the home's
     *  kept value when the screensaver does not answer. Each page load asks (PhoneHost). */
    String lang() {
        Bundle b = saver("phone_state", null, null);
        return b == null ? sa.taweeqo.home.S.lang() : sa.taweeqo.home.Tr.norm(b.getString("lang"));
    }

    @Override public Map<String, Object> state() {
        Map<String, Object> m = new LinkedHashMap<>();
        Bundle b = saver("phone_state", null, null);
        m.put("settings", b != null);
        if (b != null) {
            m.put("city", b.getString("city", ""));
            m.put("home_cards", b.getStringArrayList("home_cards") == null ? new ArrayList<String>() : b.getStringArrayList("home_cards"));
            List<Object> panels = new ArrayList<>();
            List<String> codes = b.getStringArrayList("panels"), names = b.getStringArrayList("panel_names");
            for (int i = 0; codes != null && names != null && i < codes.size() && i < names.size(); i++) {
                if ("none".equals(codes.get(i))) continue;
                Map<String, Object> p = new LinkedHashMap<>();
                p.put("id", codes.get(i));
                p.put("name", names.get(i));
                panels.add(p);
            }
            m.put("panels", panels);
            m.put("lang", sa.taweeqo.home.Tr.norm(b.getString("lang")));
            m.put("fav_bar", b.getString("fav_bar") == null ? "5" : b.getString("fav_bar"));   // an older screensaver says nothing: 5, as always   // «اللغة»: an older screensaver says nothing: ar
        }
        m.putAll(PhoneBridge.state(app));
        PhoneBridge.addAdhanLive(app, m);
        m.put("sleep_timer", PhoneApps.sleep(app));
        m.putAll(sa.taweeqo.home.GlassSource.phoneState(app));   // the glass look: which backdrop, and the veils it needs (thousandths)
        if (b != null && b.getString("idle") != null) {
            m.put("saver_idle", b.getString("idle"));
            if (b.getString("idle_s") != null) m.put("saver_idle_s", b.getString("idle_s"));   // the TV's own delay in seconds (45 s on the owner's TCL): the page shows it as the current choice
            List<Object> options = new ArrayList<>();
            for (int minutes : Schema.SAVER_IDLE) options.add(String.valueOf(minutes));
            m.put("saver_idle_options", options);
        }
        m.put("version", UpdateText.versionOf(BuildConfig.MARKETING, BuildConfig.VERSION_CODE));   // «4.0»: the name a person reads
        m.put("keys_everywhere", PhoneApps.keysEverywhere());
        m.put("dpad_everywhere", PhoneApps.dpadEverywhere());
        m.put("typing_service", PhoneApps.typingEnabled());
        m.put("a11y_stuck", sa.taweeqo.home.A11yHeal.stuck(app));   // listed as on, but Android runs none of it: the page says control of other apps is stopped
        m.put("family", PhoneApps.family(app));
        m.put("foreground", Foreground.current() != null ? "own" : "other");
        m.put("update", PhoneUpdater.status());
        return m;
    }

    @Override public Result set(Map<String, Object> v) {
        Bundle extras = new Bundle();
        boolean city = false;
        if (v.containsKey("city")) { extras.putString("city", (String) v.get("city")); city = true; }
        if (v.containsKey("home_cards")) {
            StringBuilder cards = new StringBuilder();
            for (Object x : (List<?>) v.get("home_cards")) cards.append(cards.length() > 0 ? "," : "").append((String) x);
            extras.putString("home_panel", cards.length() == 0 ? "none" : cards.toString());
        }
        if (v.containsKey("saver_idle")) extras.putString("idle", String.valueOf((Long) v.get("saver_idle")));
        if (v.containsKey("lang")) extras.putString("lang", (String) v.get("lang"));   // «اللغة»: the screensaver holds it (SaverReceiver.set checks it again)
        if (v.containsKey("fav_bar")) extras.putString("favbar", (String) v.get("fav_bar"));   // «تطبيقات في الشريط»: the screensaver holds it (SaverReceiver.set checks it again)
        if (v.containsKey("sleep_minutes") && !PhoneApps.setSleep(app, ((Long) v.get("sleep_minutes")).intValue())) return Result.fail("refused");
        if (!extras.isEmpty()) {
            Bundle r = saver("phone_set", null, extras);
            if (r == null) return Result.fail("saver_missing");
            if (!r.getBoolean("ok")) return Result.fail(r.getBoolean("idle_denied") ? "needs_permission" : "refused");
            if (city) PhoneBridge.rescheduleAdhan(app);
            if (v.containsKey("home_cards")) {
                // asked again of the screensaver: what it holds now is what was sent (fixed words in the log, never a card name)
                List<String> want = new ArrayList<>();
                for (Object x : (List<?>) v.get("home_cards")) if (!"none".equals(x)) want.add((String) x);
                Bundle now = saver("phone_state", null, null);
                List<String> got = now == null ? null : now.getStringArrayList("home_cards");
                boolean same = got != null && got.equals(want);
                android.util.Log.i("UrTVPhone", "home_cards sent=" + want.size() + " saved=" + (got == null ? -1 : got.size()) + " same=" + same);
                if (!same) return Result.fail("not_saved");
                PhoneApps.cardsChanged(app);
            }
        }
        String why = PhoneBridge.adhan(app, v);
        return why == null ? Result.ok("saved") : Result.fail(why);
    }

    @Override public Result quran(Map<String, Object> v) {
        String why = PhoneBridge.quran(app, v);
        return why == null ? Result.ok("sent") : Result.fail(why);
    }

    @Override public List<String> cities(String query) {
        Bundle r = saver("phone_cities", query, null);
        List<String> out = r == null ? null : r.getStringArrayList("cities");
        return out == null ? new ArrayList<String>() : out;
    }

    @Override public Map<String, Object> apps() {
        Map<String, Object> m = new LinkedHashMap<>();
        List<Object> apps = new ArrayList<>(), tools = new ArrayList<>();
        for (String[] a : PhoneApps.apps(app)) {
            Map<String, Object> x = new LinkedHashMap<>();
            x.put("pkg", a[0]);
            x.put("name", a[1]);
            x.put("locked", "1".equals(a[2]));
            apps.add(x);
        }
        for (String[] t : PhoneApps.tools(app)) {
            Map<String, Object> x = new LinkedHashMap<>();
            x.put("id", t[0]);
            x.put("name", t[1]);
            x.put("locked", "1".equals(t[2]));
            tools.add(x);
        }
        m.put("apps", apps);
        m.put("tools", tools);
        return m;
    }

    @Override public byte[] icon(String pkg) { return PhoneApps.icon(app, pkg); }

    @Override public byte[] backdrop() { return sa.taweeqo.home.GlassSource.png(app); }

    @Override public Result launch(String target) {
        String r = PhoneApps.launch(app, target);
        return r.equals("opened") || r.equals("pin_on_tv") ? Result.ok(r) : Result.fail(r);
    }

    @Override public Result adhanStop() { return Result.ok(PhoneBridge.stopAdhan(app) ? "done" : "nothing"); }

    @Override public Result doOp(String op) {
        if (op.equals("sleep_cancel")) return PhoneApps.setSleep(app, 0) ? Result.ok("done") : Result.fail("failed");
        Result r = launch("@saver");   // the home's own «شاشة التوقف»: the same family lock as the pill
        return r.ok ? Result.ok(r.code.equals("pin_on_tv") ? "pin_on_tv" : "done") : r;
    }

    @Override public Map<String, Object> family() { return PhoneApps.family(app); }

    // ---- 4.3 «صوري» from the phone: the screensaver keeps it (its provider checks it: a JPEG, its size, no camera data, room)

    @Override public Result photoAdd(byte[] jpeg) {
        Bundle in = new Bundle();
        in.putByteArray("jpeg", jpeg);
        Bundle out = saver("phone_photo_add", null, in);
        if (out == null) return Result.fail("failed");
        String r = out.getString("result", "photo_refused"), why = out.getString("why", "");
        if (r.equals("photo_added")) return Result.ok("photo_added");
        return Result.fail(why.equals("full") ? "photo_full" : why.equals("camera data") ? "photo_camera" : "photo_refused");
    }

    // ---- 4.3 #53 «اكتب وارسم»: a short message on the TV's screen (PhoneMessage decides, MessageActivity shows)

    private static final PhoneMessage MESSAGES = PhoneMessage.limiter();

    @Override public Result message(String text) {
        boolean ours = Foreground.current() != null;   // our home, one of our screens, or a message already shown
        PhoneMessage.Verdict v = MESSAGES.decide(text, sa.taweeqo.home.MessageActivity.on(app), sa.taweeqo.home.MessageActivity.overApps(app), ours, android.os.SystemClock.elapsedRealtime());
        if (v != PhoneMessage.Verdict.SHOW) return Result.fail(PhoneMessage.code(v));
        try {
            app.startActivity(new Intent().setClassName(app.getPackageName(), "sa.taweeqo.home.MessageActivity")
                .putExtra("text", PhoneMessage.clean(text))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
            return Result.ok(PhoneMessage.code(v));
        } catch (RuntimeException e) {
            return Result.fail("failed");
        }
    }

    // ---- 4.3 #53 «ارسم»: live strokes over the TV's screen (PhoneDraw decides and holds them, MessageActivity draws them)

    @Override public Result draw(List<?> strokes, boolean clear) {
        boolean ours = Foreground.current() != null;
        PhoneDraw.Verdict v = PhoneDraw.TV.decide(sa.taweeqo.home.MessageActivity.on(app), sa.taweeqo.home.MessageActivity.overApps(app), ours, android.os.SystemClock.elapsedRealtime());
        if (v != PhoneDraw.Verdict.SHOW) return Result.fail(PhoneDraw.code(v));
        if (clear) { PhoneDraw.TV.clear(); return Result.ok("draw_cleared"); }
        v = PhoneDraw.TV.add(strokes, android.os.SystemClock.elapsedRealtime());
        if (v != PhoneDraw.Verdict.SHOW) return Result.fail(PhoneDraw.code(v));
        if (!sa.taweeqo.home.MessageActivity.drawing()) {   // the overlay is not up yet: once, the strokes follow it by themselves
            try {
                app.startActivity(new Intent().setClassName(app.getPackageName(), "sa.taweeqo.home.MessageActivity").putExtra("draw", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION));
            } catch (RuntimeException e) {
                return Result.fail("failed");
            }
        }
        return Result.ok(PhoneDraw.code(v));
    }

    // ---- «محفظتي»: only while the TV is editing it (PortfolioPhone)

    @Override public Map<String, Object> portfolio() {
        sa.taweeqo.home.S.init(app);
        return sa.taweeqo.home.PortfolioPhone.read(app, sa.taweeqo.home.PortfolioPhone.now());
    }

    @Override public Result portfolioSave(String code, List<String> buys) {
        String r = sa.taweeqo.home.PortfolioPhone.save(app, sa.taweeqo.home.PortfolioPhone.now(), code, buys);
        return "saved".equals(r) ? Result.ok(r) : Result.fail(r);
    }

    @Override public Map<String, Object> update(String op) {
        return "install".equals(op) ? PhoneUpdater.install(app, true) : PhoneUpdater.checkVersion(app);   // «افحص التحديث» reads version.txt only; the files come with «ثبّت»
    }
}
