package sa.taweeqo.home;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import java.util.ArrayList;
import java.util.List;

/** The reminders, read from the screensaver app's tasks (its ConfigProvider, same signing key); an older screensaver app has none, and a screensaver app that is missing answers nothing. */
final class ReminderStore {
    private ReminderStore() { }

    private static final Uri TASKS = Uri.parse("content://sa.taweeqo.screensaver.config/tasks");

    /** every task that has a reminder; empty when the screensaver app is missing, too old or refuses us */
    static List<ReminderPlan.Row> read(Context c) {
        List<ReminderPlan.Row> out = new ArrayList<>();
        try (Cursor cur = c.getApplicationContext().getContentResolver().query(TASKS, null, null, null, null)) {
            if (cur == null || cur.getColumnIndex("due") < 0) return out;   // an older screensaver app has no reminders
            int id = cur.getColumnIndexOrThrow("id"), t = cur.getColumnIndexOrThrow("t"), done = cur.getColumnIndexOrThrow("done"), due = cur.getColumnIndexOrThrow("due");
            int bf = cur.getColumnIndexOrThrow("bf"), snd = cur.getColumnIndexOrThrow("snd"), wh = cur.getColumnIndexOrThrow("wh"), sn = cur.getColumnIndexOrThrow("sn");
            int rp = cur.getColumnIndex("rp"), tz = cur.getColumnIndex("tz");   // the repeat and its zone: the alarm plans the next one (an older screensaver: no zone, the TV's)
            while (cur.moveToNext()) {
                if (cur.getLong(due) <= 0) continue;
                out.add(new ReminderPlan.Row(cur.getLong(id), cur.getString(t), cur.getInt(done) != 0, cur.getLong(due), cur.getInt(bf), cur.getInt(snd) == 1, cur.getInt(wh), cur.getLong(sn),
                        rp < 0 ? ReminderPlan.NO : cur.getInt(rp), tz < 0 ? null : zone(cur.getString(tz))));
            }
        } catch (RuntimeException e) {   // not installed, no permission
            out.clear();
        }
        return out;
    }

    /** the zone of an id such as "Asia/Riyadh"; null (the TV's own) when it is empty or unknown */
    static java.util.TimeZone zone(String id) {
        if (id == null || id.isEmpty()) return null;
        java.util.TimeZone z = java.util.TimeZone.getTimeZone(id);
        return "GMT".equals(z.getID()) && !"GMT".equals(id) ? null : ZoneFix.zone(id);   // issue #55: the offset the page uses
    }

    /** The cards already delivered (ReminderPlan.key), kept on the disk: a duplicate alarm or a restart delivers none twice. */
    static java.util.Set<String> delivered(Context c) {
        String s = c.getApplicationContext().getSharedPreferences("reminders", Context.MODE_PRIVATE).getString("delivered", "");
        java.util.Set<String> out = new java.util.LinkedHashSet<>();
        for (String k : s.split(",")) if (!k.isEmpty()) out.add(k);
        return out;
    }

    static void setDelivered(Context c, java.util.Set<String> keys) {
        c.getApplicationContext().getSharedPreferences("reminders", Context.MODE_PRIVATE).edit().putString("delivered", String.join(",", keys)).commit();
    }

    static boolean done(Context c, long id) {
        ContentValues v = new ContentValues();
        v.put("id", id);
        try { return c.getApplicationContext().getContentResolver().update(TASKS, v, null, null) > 0; } catch (RuntimeException e) { return false; }
    }

    static boolean snooze(Context c, long id, int minutes) {
        ContentValues v = new ContentValues();
        v.put("id", id);
        v.put("snooze", minutes);
        try { return c.getApplicationContext().getContentResolver().update(TASKS, v, null, null) > 0; } catch (RuntimeException e) { return false; }
    }
}
