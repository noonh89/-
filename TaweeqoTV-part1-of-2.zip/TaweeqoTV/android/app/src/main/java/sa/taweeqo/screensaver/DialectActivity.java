package sa.taweeqo.screensaver;

/** «وش معناها؟»: كلمة من لهجاتنا، والفرق تختار معناها (CultureQuizActivity) */
public class DialectActivity extends CultureQuizActivity {
    @Override protected String id() { return "dialect"; }
    @Override protected CultureQuiz.Item[] deck() { return CultureQuiz.DIALECT; }
}
