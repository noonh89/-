package sa.taweeqo.screensaver;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * ألعاب طويقو الجماعية بريموت واحد (CultureQuiz): سؤال في الصندوق الملوّن والخيارات تحته. الفريق اللي عليه الدور يختار جوابه بالأسهم ويضغط OK،
 * الجواب الصح يخضرّ ويطلع للفريق نقطة، وOK مرة ثانية للسؤال التالي والفريق اللي بعده. كل لعبة صنف صغير يعطي id() و deck().
 */
public abstract class CultureQuizActivity extends GameActivity {
    enum Screen { SETUP, ASK, END }

    static final int[] TEAMS = {1, 2, 3, 4};

    private GameChips chips; private CultureQuiz.Engine game; private String[] names = new String[0];
    private Screen screen = Screen.SETUP; private int sel; private final Random rnd = new Random();

    /** the questions of this game */
    protected abstract CultureQuiz.Item[] deck();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        chips = new GameChips()
            .add("teams", S.t("الفرق"), new String[]{num(1), num(2), num(3), num(4)}, 1)
            .add("count", S.t("الأسئلة"), new String[]{num(5), num(10), num(15)}, 1);
        remembered(soundChip(chips));
    }

    @Override protected boolean inPlay() { return screen == Screen.ASK; }
    @Override protected void onEndRound() { if (game != null) { game.finish(); go(Screen.END); play(QuizSound.FANFARE); } }

    private void go(Screen s) { screen = s; sel = 0; redraw(); }

    private void start() {
        List<CultureQuiz.Item> picks = CultureQuiz.pick(deck(), CultureQuiz.COUNTS[chips.picked("count")], GamePrefs.recent(this, id()), rnd);
        if (picks.isEmpty()) { toast(S.t("قريبًا")); return; }
        List<String> ids = new ArrayList<>();
        for (CultureQuiz.Item it : picks) ids.add(it.id);
        GamePrefs.remember(this, id(), ids);
        int teams = TEAMS[chips.picked("teams")];
        names = teamNames(teams);
        game = new CultureQuiz.Engine(teams, picks);
        go(Screen.ASK);
    }

    // ---------------------------------------------------------------- keys

    @Override protected void onKey(boolean back, boolean ok, int dx, int dy) {
        switch (screen) {
            case SETUP: if (keySetup(chips, back, ok, dx, dy)) start(); return;
            case ASK: {
                if (back) { openPause(); return; }
                if (game.answered()) {   // the answer is shown: OK goes on
                    if (!ok) return;
                    if (game.next()) go(Screen.ASK); else { go(Screen.END); play(QuizSound.FANFARE); }
                    return;
                }
                int n = game.current().choices.length, cols = 2;
                if (ok) { game.choose(sel); play(game.right() ? QuizSound.CHIME : QuizSound.LOW); redraw(); return; }
                int col = sel % cols, row = sel / cols;
                if (dx != 0) col = Math.max(0, Math.min(cols - 1, col + dx));
                if (dy != 0) row = Math.max(0, Math.min((n - 1) / cols, row + dy));
                int to = Math.min(n - 1, row * cols + col);
                if (to != sel) { sel = to; redraw(); }
                return;
            }
            case END: {
                if (back) { finish(); return; }
                int v = keyButtons(sel, 3, ok, dx);
                if (v >= 0) { if (v != sel) { sel = v; redraw(); } return; }
                if (v == -1) start(); else if (v == -2) go(Screen.SETUP); else finish();
                return;
            }
            default:
        }
    }

    // ---------------------------------------------------------------- screens

    @Override protected void draw() {
        switch (screen) {
            case SETUP: setup(chips, S.t("ابدأ")); break;
            case ASK: drawAsk(); break;
            case END: podium(game.score, names, sel); break;
            default:
        }
    }

    private void drawAsk() {
        CultureQuiz.Item it = game.current();
        if (it == null) return;
        String team = names[game.turn];
        String meta = game.score.n == 1 ? S.t("السؤال %s من %s", num(game.index + 1), num(game.total()))
                                        : S.t("السؤال %s من %s: دور %s", num(game.index + 1), num(game.total()), team);
        CharSequence words = it.q.contains(CultureQuiz.BLANK)   // «كمّل المثل»: صندوق متقطّع بعرض الجواب، والجواب فيه بعد الاختيار
            ? blanked(digits(it.q), CultureQuiz.BLANK, digits(it.choices[it.answer]), null, game.answered()) : digits(it.q);
        question(meta, words, 440);
        int n = it.choices.length; float w = 852, h = 136, gap = 24;
        for (int i = 0; i < n; i++) {
            int state = !game.answered() ? (i == sel ? STAMP_FOCUS : STAMP)
                      : i == it.answer ? STAMP_RIGHT : i == game.chosen ? STAMP_WRONG : STAMP;
            root.addView(answer(letter(i), digits(it.choices[i]), state), at(w, h, 96 + (i % 2) * (w + gap), 472 + (i / 2) * (h + gap)));
        }
        float lineY = n > 2 ? 472 + 2 * (h + gap) : 472 + h + gap;
        if (game.answered()) {
            String line = game.right()
                ? (game.score.n == 1 ? S.t("صح! نقطة لكم") : S.t("صح! نقطة لـ %s", team))
                : (it.note != null ? digits(it.note) : S.t("الجواب الصح: %s", digits(it.choices[it.answer])));
            TextView v = text(line, 48, game.right() ? L.ok : L.pink, true); v.setSingleLine(true);
            root.addView(v, at(1728, 64, 96, lineY));
            hints(S.t("اختيار"), game.over() || game.index + 1 >= game.total() ? S.t("النتيجة") : S.t("السؤال التالي"), S.t("رجوع"), S.t("إيقاف مؤقت"));
        } else {
            String line = game.score.n == 1 ? S.t("اختاروا جوابكم واضغطوا OK") : S.t("دور %s: اختاروا جوابكم واضغطوا OK", team);
            TextView v = text(line, 44, L.ink, true); v.setSingleLine(true);
            root.addView(v, at(1728, 64, 96, lineY));
            hints("◀ ▶ ▲ ▼", S.t("الاختيار"), S.t("اختيار"), S.t("تأكيد"), S.t("رجوع"), S.t("إيقاف مؤقت"));
        }
        sidesBar(game.score, names, game.turn, 860);
    }
}
