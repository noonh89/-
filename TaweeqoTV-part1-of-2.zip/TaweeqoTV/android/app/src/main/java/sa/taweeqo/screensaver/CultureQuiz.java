package sa.taweeqo.screensaver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * ألعاب طويقو الجماعية (فرق بريموت واحد): «كمّل المثل»، «وش معناها؟» و«صح ولا خطأ». سؤال وخيارات، الفريق اللي عليه الدور يختار جوابه بالريموت،
 * والجواب الصح بنقطة. لا Android هنا (مثل MissingWord): الأسئلة، الاختيار، والدور والنقاط. المحتوى عربي في اللغتين، مثل «خمّن الكلمة».
 */
final class CultureQuiz {
    private CultureQuiz() {}

    static final int[] COUNTS = {5, 10, 15};

    static final class Item {
        /** `answer` is the right choice's index in `choices`; `note` (may be null) is said after the answer (the fact behind a «خطأ») */
        final String id, q, note; final String[] choices; final int answer;
        Item(String id, String q, String note, String[] choices, int answer) { this.id = id; this.q = q; this.note = note; this.choices = choices; this.answer = answer; }
    }

    /** a question whose right answer is written first (the choices are shuffled when it is picked) */
    private static Item mc(String id, String q, String... choices) { return new Item(id, q, null, choices, 0); }
    /** a «صح ولا خطأ» statement; a false one carries the right fact */
    private static Item tf(String id, String q, boolean right, String note) { return new Item(id, q, note, new String[]{"صح", "خطأ"}, right ? 0 : 1); }

    static final String BLANK = "___";

    static final Item[] PROVERBS = {
        mc("p1", "مد رجولك على قد ___", "لحافك", "فراشك", "بيتك", "طريقك"),
        mc("p2", "الجار قبل ___", "الدار", "الطريق", "الأهل", "السفر"),
        mc("p3", "اللي ما يعرف الصقر ___", "يشويه", "يبيعه", "يطيّره", "يصيده"),
        mc("p4", "من طق الباب ___", "سمع الجواب", "دخل البيت", "لقى الأصحاب", "فتحوا له"),
        mc("p5", "القرد في عين أمه ___", "غزال", "أسد", "حصان", "نمر"),
        mc("p6", "يا غريب كن ___", "أديب", "قريب", "حبيب", "نجيب"),
        mc("p7", "الطيور على أشكالها ___", "تقع", "تطير", "تغرّد", "تعيش"),
        mc("p8", "عصفور في اليد ولا عشرة على ___", "الشجرة", "السطح", "الجبل", "الطريق"),
        mc("p9", "كل إناء بما فيه ___", "ينضح", "يمتلئ", "يفيض", "ينكسر"),
        mc("p10", "باب النجار ___", "مخلوع", "مفتوح", "مقفول", "جديد"),
        mc("p11", "من شب على شيء ___", "شاب عليه", "تعلّمه", "نساه", "تركه"),
        mc("p12", "اللي فات ___", "مات", "نام", "طار", "صار"),
        mc("p13", "الوقت من ___", "ذهب", "فضة", "ماس", "حديد"),
        mc("p14", "كثر الطباخين ___", "يحرق الطبخة", "يكثّر الأكل", "يبرّد القدر", "يملّح الطبخة"),
        mc("p15", "خذ الحكمة من أفواه ___", "المجانين", "الكبار", "الشعراء", "الصغار"),
        mc("p16", "الصيت ولا ___", "الغنى", "الفقر", "الكرم", "القوة"),
        mc("p17", "اللي بيته من زجاج لا يرمي الناس ___", "بالحجارة", "بالورد", "بالماء", "بالرمل"),
        mc("p18", "إذا فات الفوت ما ينفع ___", "الصوت", "البيت", "الحوت", "الوقت"),
        mc("p19", "اربط الحمار مطرح ما يقول ___", "صاحبه", "جاره", "أبوه", "الناس"),
        mc("p20", "القناعة كنز ___", "لا يفنى", "لا يباع", "لا يشترى", "لا يضيع"),
    };

    static final Item[] DIALECT = {
        mc("d1", "وش معنى «الحين»؟", "الآن", "أمس", "بعدين", "دائمًا"),
        mc("d2", "وش معنى «طفشان»؟", "ملّان وضجران", "جوعان", "فرحان", "نعسان"),
        mc("d3", "وش معنى «مدري»؟", "لا أدري", "أكيد", "ربما", "نعم"),
        mc("d4", "وش معنى «سولف»؟", "تحدّث", "نام", "اكتب", "امشِ"),
        mc("d5", "وش معنى «هقوتي»؟", "ظنّي وتوقّعي", "بيتي", "سيارتي", "صديقي"),
        mc("d6", "وش معنى «فزعة»؟", "نجدة ومساعدة", "خوف", "حفلة", "سفر"),
        mc("d7", "وش معنى «قلّطوا» لما يحطون الأكل؟", "تفضّلوا", "اسكتوا", "اطلعوا", "ناموا"),
        mc("d8", "وش معنى «خويّي»؟", "رفيقي وصديقي", "جاري", "عمّي", "مديري"),
        mc("d9", "وش معنى «بزر»؟", "طفل صغير", "شيخ كبير", "ضيف", "جار"),
        mc("d10", "وش معنى «كشتة»؟", "نزهة في البر", "حفلة زواج", "سفرة طويلة", "وجبة غداء"),
        mc("d11", "وش معنى «دحين» بالحجازي؟", "الآن", "غدًا", "قبل شوي", "أبدًا"),
        mc("d12", "وش معنى «مرّه» في «مرّه حلو» بالحجازي؟", "جدًا", "قليلًا", "أبدًا", "أحيانًا"),
        mc("d13", "وش معنى «يهايط»؟", "يتفاخر ويبالغ", "يضحك", "يركض", "يطبخ"),
        mc("d14", "وش معنى «السنع»؟", "الأصول والآداب", "الطعام", "الشعر", "الخيمة"),
        mc("d15", "وش معنى «الزهبة»؟", "التجهيزات والأغراض", "الذهب", "الزحمة", "الهدية"),
        mc("d16", "وش معنى «مهوب»؟", "ليس", "كثير", "هنا", "قريب"),
        mc("d17", "وش معنى «يبي»؟", "يريد", "يبكي", "يأكل", "يرى"),
        mc("d18", "وش معنى «سِيده»؟", "على طول ومباشرة", "ببطء", "يمين", "أمس"),
        mc("d19", "وش «الدلّة»؟", "إبريق القهوة", "الفنجان", "الصينية", "المبخرة"),
        mc("d20", "وش معنى «عاد» في «لا تتأخر عاد»؟", "تأكيد بمعنى إذن", "رجع", "تعب", "مرة ثانية"),
    };

    static final Item[] FACTS = {
        tf("f1", "جبل طويق يمتد في منطقة نجد", true, null),
        tf("f2", "الدرعية هي عاصمة الدولة السعودية الأولى", true, null),
        tf("f3", "قصر المصمك في مدينة جدة", false, "قصر المصمك في الرياض"),
        tf("f4", "في العُلا موقع الحِجر (مدائن صالح)", true, null),
        tf("f5", "فن القط العسيري أصله من منطقة الجوف", false, "القط العسيري من منطقة عسير"),
        tf("f6", "يوم التأسيس يوافق ٢٢ فبراير", true, null),
        tf("f7", "اليوم الوطني السعودي يوافق ٢٣ سبتمبر", true, null),
        tf("f8", "القهوة السعودية تنصب للضيف باليد اليمنى", true, null),
        tf("f9", "الكليجا من أشهر أكلات القصيم", true, null),
        tf("f10", "أبها عاصمة منطقة تبوك", false, "أبها عاصمة منطقة عسير"),
        tf("f11", "العرضة السعودية رقصة شعبية بالسيوف والطبول", true, null),
        tf("f12", "جزر فرسان في البحر الأحمر", true, null),
        tf("f13", "واحة الأحساء في المنطقة الغربية", false, "الأحساء في المنطقة الشرقية"),
        tf("f14", "السدو حرفة نسيج بدوية", true, null),
        tf("f15", "منطقة «البلد» هي جدة التاريخية", true, null),
        tf("f16", "حائل تشتهر بجبلي أجا وسلمى", true, null),
        tf("f17", "المسجد النبوي في مكة المكرمة", false, "المسجد النبوي في المدينة المنورة"),
        tf("f18", "الريال السعودي فيه ١٠٠ هللة", true, null),
        tf("f19", "مدينة الطائف تشتهر بالورد", true, null),
        tf("f20", "البشت لباس تراثي للنساء فقط", false, "البشت لباس رجالي"),
    };

    /**
     * `count` questions of `deck`: first the ones not in `recent` (the last played on this TV), shuffled; a multiple choice gets its choices shuffled
     * (a «صح ولا خطأ» keeps صح then خطأ).
     */
    static List<Item> pick(Item[] deck, int count, List<String> recent, Random rnd) {
        List<Item> fresh = new ArrayList<>(), old = new ArrayList<>();
        for (Item it : deck) (recent != null && recent.contains(it.id) ? old : fresh).add(it);
        Collections.shuffle(fresh, rnd); Collections.shuffle(old, rnd);
        fresh.addAll(old);
        List<Item> out = new ArrayList<>();
        for (int i = 0; i < Math.min(count, fresh.size()); i++) out.add(shuffled(fresh.get(i), rnd));
        return out;
    }

    private static Item shuffled(Item it, Random rnd) {
        if (it.choices.length <= 2) return it;
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < it.choices.length; i++) order.add(i);
        Collections.shuffle(order, rnd);
        String[] c = new String[it.choices.length]; int answer = 0;
        for (int i = 0; i < c.length; i++) { c[i] = it.choices[order.get(i)]; if (order.get(i) == it.answer) answer = i; }
        return new Item(it.id, it.q, it.note, c, answer);
    }

    /** one game: the questions, whose turn, the picked choice (-1 before it), the points */
    static final class Engine {
        final GameScore score; final List<Item> items;
        int index, turn, chosen = -1;
        Engine(int teams, List<Item> items) { score = new GameScore(teams); this.items = items; }
        Item current() { return index < items.size() ? items.get(index) : null; }
        int total() { return items.size(); }
        boolean answered() { return chosen >= 0; }
        boolean right() { Item it = current(); return it != null && chosen == it.answer; }
        /** the team in turn answers; a right answer is one point. Once only per question. */
        void choose(int i) {
            Item it = current();
            if (it == null || answered() || i < 0 || i >= it.choices.length) return;
            chosen = i; score.newRound();
            if (i == it.answer) score.add(turn, 1);
        }
        /** the next question and the next team; false when the game is over */
        boolean next() { if (!answered()) return true; index++; chosen = -1; turn = score.after(turn); return index < items.size(); }
        boolean over() { return index >= items.size(); }
        void finish() { index = items.size(); }
    }
}
