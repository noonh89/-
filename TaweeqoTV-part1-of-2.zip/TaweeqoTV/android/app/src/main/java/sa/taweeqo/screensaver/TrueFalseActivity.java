package sa.taweeqo.screensaver;

/** «صح ولا خطأ»: معلومة عن السعودية وتراثها، والفرق تقول صح أو خطأ (CultureQuizActivity) */
public class TrueFalseActivity extends CultureQuizActivity {
    @Override protected String id() { return "true-false"; }
    @Override protected CultureQuiz.Item[] deck() { return CultureQuiz.FACTS; }
}
