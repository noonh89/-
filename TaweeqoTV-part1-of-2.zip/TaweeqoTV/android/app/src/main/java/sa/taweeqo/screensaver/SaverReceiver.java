package sa.taweeqo.screensaver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * The screensaver's settings from ADB, for agents (people use SettingsActivity). Only the shell can send
 * these: the manifest requires android.permission.DUMP. optimize/saver.sh wraps them.
 *
 *   am broadcast -n sa.taweeqo.screensaver/.SaverReceiver -a sa.taweeqo.screensaver.GET
 *   am broadcast -n sa.taweeqo.screensaver/.SaverReceiver -a sa.taweeqo.screensaver.CITIES
 *   am broadcast -n sa.taweeqo.screensaver/.SaverReceiver -a sa.taweeqo.screensaver.SET
 *       [--es city 'الرس'] [--es lat 25.86 --es lon 43.49 --es tz Asia/Kuwait]   (tz is needed for a place that is not in the list) [--es teams '136013:Al-Hilal,150643:Al-Zulfi']
 *       [--es panel prayers] [--es panel2 hourly|none] [--es home_panel prayers,hourly,verse|none] [--es greeting on|off] [--es homephotos same|own] [--es homepacks id,id|none] [--es homeours on|off] [--es albummode seconds|ten|minute] [--es albumtitle on|off] [--es albumfit fit|fill] [--es albumsize normal|tall] [--es cleartext on|off] [--es looksync on|off] [--es surface quick|cards|tray:30..100:look|glass|graphite] [--es accent amber|gold|green|teal|sky|violet|rose|coral|default] [--es baropacity 30..100] [--es walldim 0..90] [--es focusstyle solid|frame|glow] [--es albummode seconds|minute] [--es albumdate on|off] [--es pillshidden markets,matches,center|none] [--es listenpill on|off] [--es updatebell on|off] [--es watchnext on|off] [--es appearance dark|light|auto] [--es look glass|graphite|navy|clean] [--es homelayout classic|football] [--es favbar 5|6|7|8|all] [--es pagesdark on|off] [--es adhanbar on|off] [--es yearstrip on|off] [--es minrating 7]
 *       [--es sunrise on|off] [--es prayerbar on|off] [--es wxmore on|off] [--es months default|levant] [--es verse day|3] [--es versekind both|verse|hadith] [--es seconds on|off] [--es backexit press|hold|three] [--es occasion on|off] [--es nightdim on|off] [--es taskspill on|off] [--es backsaver on|off] [--es genres Drama,Comedy] [--es langs English]
 *       [--es photos 30] [--es idle 10] [--es digits hindi|latin] [--es hijrioffset -2..2] [--es clock24 on|off] [--es ramtier low|mid|normal|auto] [--es lang ar|en]
 *       [--es cardstyle current|dark1|glass1|dark3|glass3] [--es national auto|off]
 *       [--es markets tasi,gold,btc] [--es mkstyle arrows|prices] [--es mkbar on|off] [--es clocksize large|medium|small] [--es stocks 2222,1120,AAPL] [--es stkchg pct|amount]
 *       [--es leagues 'Saudi-Arabian Pro League,NBA']
 *       [--es prayermethod gulf|auto]   («طريقة الحساب»: auto = the country's own, gulf = the Gulf method for any place; an old «jafari» is taken as auto, 4.3 A4)
 *       [--es prayeradj on|off] [--es adj_fajr +2 --es adj_dhuhr 0 --es adj_asr 0 --es adj_maghrib -1 --es adj_isha 0]   («تعديل وقت الصلاة», minutes -20..20)
 *       [--es slot matches|weather|fasting|countdown|markets|none] [--es countdown 2026-12-01|clear --es cdname 'رحلة الصيف']
 *   am broadcast -n sa.taweeqo.screensaver/.SaverReceiver -a sa.taweeqo.screensaver.UPDATE
 *   am broadcast -n sa.taweeqo.screensaver/.SaverReceiver -a sa.taweeqo.screensaver.TASKS
 *       --es op list | add --es text 'نص' | done --ei n 1 | del --ei n 1 | clear
 *   am broadcast -n sa.taweeqo.screensaver/.SaverReceiver -a sa.taweeqo.screensaver.PHOTOS
 *       --es op list | add --ei size BYTES | add --ei size BYTES --es path /data/local/tmp/urtv-own/in.jpg | del --ei n 1 | clear | mode --es mode mix|only
 *
 * updatechannel = latest (the default), beta («النسخ التجريبية») or next: where «تحديث تلفزيوني» (the TV's screen and the phone page) and the newest-version line read the
 * version and the APKs, the apk-latest or the apk-next release. For TESTING an update only, set by agents; no screen shows it, the settings export leaves
 * it out, and every signature, newer-version and permission check is the same.
 * leagues = whole leagues (Prefs.LEAGUES, up to Prefs.MAX_LEAGUES; the English or the Arabic name; "" = none): every game of every
 * club in them joins the followed teams' games.
 * PHOTOS = «صوري», the owner's own photos (Own, up to 10; optimize/photos.sh): "add" keeps the photo the shell just wrote
 * through ConfigProvider (.../own-in), or, with path, one in /data/local/tmp/urtv-own/ (only where the app may read it);
 * mode = mix (they join ours, as always) or only.
 * appearance = «المظهر ← الإضاءة» of the home screen: dark (the default), light, or auto (light from sunrise until Maghrib in the city).
 * look = «المظهر ← الشكل» of all our screens: glass (the default), graphite, navy or clean.
 * listenpill = the «تلاوة وأذان» button on the home screen (on, the default, or off: only the button goes, the adhan and the Quran stay).
 * pagesdark = the home's markets and matches pages in the dark look (on, the default) or in the home's look (off).
 * watchnext = «أكمل المشاهدة» under the home screen's favourites (on, the default, or off); it needs the home app's TV listings permission.
 * updatebell = the «جرس التحديثات» on the home screen (on, the default, or off: only the bell goes; it shows only while the Play Store has updates waiting).
 * greeting = the greeting and the weather line above the home screen's clock (on, the default, or off: the plain good-morning).
 * favbar = how many favourites the home's tray shows whole at once: 5 (the default) to 10, or all (every favourite, up to 10, all whole: no scrolling). 4.3.1: 9 and 10 are whole sizes again (smaller tiles).
 * yearstrip = the slim year strip under the screensaver's clock (on, or off, the default).
 * sunrise, prayerbar, wxmore = on or off (the default): the sunrise after Fajr in the prayer panel, the bar under it, the humidity and wind.
 * months = default («أكتوبر») or levant («تشرين الأول»), the Gregorian month's names on both screens.
 * occasion, nightdim, taskspill = on (the default, as always) or off: «المناسبة القادمة» at the bottom middle of the screensaver (the
 * countdown to Ramadan and the feasts), «تعتيم الليل» (the screensaver darker at night), the «المهام» button on the home screen.
 * backsaver = on or off (the default): «الرجوع يفتح شاشة التوقف», Back on our home starts the screensaver; the home follows it when it
 * changes (optimize/dock.sh backsaver sends it beside the home's own switch, so the row says what the home does).
 * verse = day (the default: a verse one day, a hadith the next) or 3 (a new one every 3 minutes): the verse-or-hadith card (QuoteEvery).
 * versekind = both (the default, as always), verse or hadith: what that card shows (VerseKind).
 * seconds = on or off (the default): «إظهار الثواني», the seconds on the screensaver's clock.
 * backexit = press (the default, as always), hold or three: «الخروج من تلفزيونك», how Back leaves our home where the TV keeps its own (HomeExit).
 * slot = what the bottom-left slot shows (Prefs.SLOTS). countdown = the date (YYYY-MM-DD) slot=countdown counts down to, or
 * "clear"; cdname = its name (up to 40 characters).
 * national = auto (as always from now: the quiet green look on National Day, 21-25 September, and Founding Day, 20-24 February) or off.
 * cardstyle = the look of the card beside the clock (Prefs.CARD_STYLES; current is the plain card).
 * panel2 = «بطاقة ثانية», a second card beside the clock while it is small (SecondCard): one of the screensaver's cards but the
 * first one, or none (the default). Kept with any clock size; the page shows it only beside the small clock.
 * mkbar = the markets line at the top, on (default) or off (the weather stays; the list is kept); clocksize = the screensaver's clock.
 * markets = up to four of Prefs.MARKETS at the top left, in order; mkstyle = arrows only (as always) or the price and the day's change.
 * stocks = the watchlist of the stocks card (panel stocks): up to Prefs.MAX_STOCKS Tadawul codes (4 digits) or US tickers.
 * stkchg = «تغيّر الأسهم»: every stock's change as a percentage (pct, the default) or an amount.
 * clock24 = «ساعة ٢٤»: every time of day as 24-hour (on) or 12-hour with ص and م (off, the default; ClockSetting).
 * lang = «اللغة»: ar (the default, as always) or en, the words and direction of both apps' screens, the page and the phone page (docs/ENGLISH.md).
 * digits = hindi (١٢٣, as always) or latin (123). photos = minutes between background photos, or 30s on a TV with 2 GB (PhotoInterval). idle = minutes before the TV starts the
 * screensaver (Prefs.IDLE_MINUTES): this is the system's screen_off_timeout, which a receiver (it runs as this
 * app, not as the shell) may write only when the app holds WRITE_SETTINGS; otherwise it says so and
 * optimize/saver.sh sets it from the shell instead. Nothing changes unless the extra is given.
 *
 * The answer is in the "data" of am's output. Unknown values are refused with a message, nothing half-saved.
 */
public class SaverReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Prefs p = new Prefs(c);
        String action = String.valueOf(i.getAction());
        switch (action) {
            case "sa.taweeqo.screensaver.GET":
                setResultData(describe(c, p));
                return;
            case "sa.taweeqo.screensaver.CITIES": {
                StringBuilder b = new StringBuilder();
                for (Cities.Region r : Cities.REGIONS) {
                    b.append(r.name).append(": ");
                    for (String[] city : r.cities) b.append(city[0]).append("، ");
                    b.setLength(b.length() - 2);
                    b.append('\n');
                }
                setResultData(b.toString().trim());
                return;
            }
            case "sa.taweeqo.screensaver.UPDATE": {
                final PendingResult pending = goAsync();   // a download: off the main thread
                final Context app = c.getApplicationContext();
                new Thread(() -> {
                    try { pending.setResultData("update: " + Updater.check(app, true)); }
                    finally { pending.finish(); }   // S5: the broadcast is finished even when the check throws
                }).start();
                return;
            }
            case "sa.taweeqo.screensaver.SET":
                setResultData(set(c, p, i));
                return;
            case "sa.taweeqo.screensaver.TASKS":
                setResultData(tasks(c, p, i));
                return;
            case "sa.taweeqo.screensaver.PHOTOS":
                setResultData(photos(c, p, i));
                return;
            default:
                setResultData("error: unknown action " + action);
        }
    }

    /** The name is a built-in city, in full or as the short form that fits only one. */
    private static boolean inList(String name) {
        for (Cities.Region r : Cities.REGIONS) for (String[] x : r.cities) if (x[0].equals(name)) return true;
        return CityMatch.find(name).size() == 1;
    }

    /** The one place a setting is checked and saved: the ADB receiver and the launcher's phone control (ConfigProvider.call) both come here. */
    static String set(Context c, Prefs p, Intent i) {
        // check everything first, then save: a typo never leaves half the settings changed
        String[] city = null;
        String name = i.getStringExtra("city"), lat = i.getStringExtra("lat"), lon = i.getStringExtra("lon");
        String tz = i.getStringExtra("tz");   // only for a place of your own; a built-in city is Asia/Riyadh
        String cityCountry = i.getStringExtra("country");
        if (cityCountry != null) {
            if (name == null || lat == null || lon == null || tz == null || !cityCountry.matches("(?:[A-Za-z]{2})?"))
                return "error: country is a two-letter code with city, lat, lon and tz";
            cityCountry = cityCountry.toUpperCase(java.util.Locale.ROOT);
        }
        // 4.3 R1-2: one of the two alone was dropped while the answer said «saved»
        if ((lat == null) != (lon == null)) return "error: lat and lon go together (both, with city)";
        if (tz != null && (name == null || lat == null || lon == null))
            return "error: tz goes with city, lat and lon (a built-in city is Asia/Riyadh)";
        if (tz != null && !Arrays.asList(java.util.TimeZone.getAvailableIDs()).contains(tz))
            return "error: tz is a time zone like Asia/Kuwait or Africa/Cairo";
        if (name != null) {
            if (lat != null && lon != null) {
                if (!lat.matches("-?\\d{1,2}(\\.\\d+)?") || !lon.matches("-?\\d{1,3}(\\.\\d+)?"))
                    return "error: lat/lon must be numbers like 25.86 / 43.49";
                // 4.3 R1-3: on the Earth: latitude -90..90, longitude -180..180
                if (Math.abs(Double.parseDouble(lat)) > 90 || Math.abs(Double.parseDouble(lon)) > 180)
                    return "error: lat is -90 to 90 and lon is -180 to 180";
                // a place of your own has its own time zone, and a missing one would be guessed (the TV's, Riyadh's): ask for it
                if (tz == null && !inList(name))
                    return "error: add the time zone for a place that is not in the list, e.g. --es tz Asia/Riyadh or Asia/Kuwait";
                if (tz == null) tz = CityMatch.zoneOf(name);   // a list name with coordinates of its own: its country's zone, not the TV's
                city = new String[] {name, lat, lon};
            } else {
                if (city == null) {   // a short form of a built-in name: «مكة» for «مكة المكرمة»
                    List<String[]> hits = CityMatch.find(name);
                    if (hits.size() == 1) city = hits.get(0);
                    else if (hits.size() > 1) {
                        List<String> names = new ArrayList<>();
                        for (String[] h : hits) names.add(Cities.country(h) + "|" + (h.length > 4 ? h[4] : h[0]));
                        return "error: «" + name + "» fits several cities: " + Prefs.join(names, "، ") + " — give one of them in full";
                    }
                }
                if (city == null) return "error: city not in the built-in list; give --es lat and --es lon too (CITIES lists them)";
            }
        }
        List<String> teams = null;
        String t = i.getStringExtra("teams");
        if (t != null) {
            teams = new ArrayList<>();
            for (String part : t.split(",")) {
                part = part.trim();
                if (part.isEmpty()) continue;
                String[] kv = part.split(":", 2);
                if (!kv[0].matches("\\d+")) return "error: teams are id:EnglishName, e.g. 136013:Al-Hilal";
                String en = kv.length > 1 ? kv[1].trim() : "";
                // the bundled list knows the club by id (its Arabic name as the screen shows it); a club outside
                // the list gets the name made from its English one
                TeamSearch.Team known = Teams.byId(c, kv[0]);
                String ar = known != null && !known.ar.isEmpty() ? known.ar
                    : en.isEmpty() ? "#" + kv[0] : Arabic.team(c, en);
                teams.add(kv[0] + "|" + ar.replace("|", " ").replace(";", " "));
            }
            if (teams.size() > Prefs.MAX_TEAMS) return "error: at most " + Prefs.MAX_TEAMS + " teams";
        }
        String panel = i.getStringExtra("panel"), home = i.getStringExtra("home_panel");
        if (panel != null && Prefs.homeOnly(panel)) return "error: " + panel + " is a home-screen card only (the screensaver's panel already shows it): optimize/saver.sh home-card " + panel;
        if (panel != null && !isPanel(panel)) return "error: panel is one of " + panels();
        String panel2 = i.getStringExtra("panel2");   // checked against the first card it will sit beside: this one's new one, else today's
        if (panel2 != null) {
            String why = SecondCard.refuse(panel2, panel != null ? panel : p.panel(), Prefs.SAVER_PANELS);
            if (why != null) return why;
        }
        List<String> homeCards = null;
        if (home != null) {
            homeCards = new ArrayList<>();
            for (String h : home.split(",")) {
                h = h.trim();
                if (h.isEmpty() || "none".equals(h)) continue;
                if (!isPanel(h)) return "error: home_panel is up to " + Prefs.HOME_CARDS + " of " + panels() + ", separated by commas";
                if (!homeCards.contains(h)) homeCards.add(h);
            }
            if (homeCards.size() > Prefs.HOME_CARDS) return "error: home_panel is at most " + Prefs.HOME_CARDS + " cards";
        }
        String adhanBar = i.getStringExtra("adhanbar");
        if (adhanBar != null && !"on".equals(adhanBar) && !"off".equals(adhanBar))
            return "error: adhanbar is one of on off";
        String updateChannel = i.getStringExtra("updatechannel");
        if (updateChannel != null && !"latest".equals(updateChannel) && !"next".equals(updateChannel) && !"beta".equals(updateChannel))
            return "error: updatechannel is one of latest beta next";
        String prayerAdj = i.getStringExtra("prayeradj");
        if (prayerAdj != null && !"on".equals(prayerAdj) && !"off".equals(prayerAdj))
            return "error: prayeradj is one of on off";
        String prayerMethod = i.getStringExtra("prayermethod");
        if (prayerMethod != null && PrayerMethod.parse(prayerMethod) == null)
            return "error: prayermethod is one of gulf auto";
        int[] adj = null;   // «تعديل وقت الصلاة»: each given prayer is a whole number of minutes, −20..20; the rest stay
        for (int k = 0; k < PrayerAdj.COUNT; k++) {
            String v = i.getStringExtra("adj_" + PrayerAdj.KEYS[k]);
            if (v == null) continue;
            Integer n = PrayerAdj.parse(v.trim());
            if (n == null) return "error: " + PrayerAdj.KEYS[k] + " is a whole number of minutes from -" + PrayerAdj.MAX + " to " + PrayerAdj.MAX + ", like +2 or -1";
            if (adj == null) adj = p.prayerAdj();
            adj[k] = n;
        }
        Integer hijriOffset = null;   // «فرق التاريخ الهجري»: a whole number of days, -2..2
        String hijriExtra = i.getStringExtra("hijrioffset");
        if (hijriExtra != null) {
            hijriOffset = HijriOffset.parse(hijriExtra.trim());
            if (hijriOffset == null) return "error: hijrioffset is a whole number of days from -" + HijriOffset.MAX + " to " + HijriOffset.MAX + ", like -1 or +1 (0 = Umm al-Qura as it is)";
        }
        String yearStrip = i.getStringExtra("yearstrip");
        if (yearStrip != null && !"on".equals(yearStrip) && !"off".equals(yearStrip))
            return "error: yearstrip is one of on off";
        String sunrise = i.getStringExtra("sunrise"), prayerBar = i.getStringExtra("prayerbar"), wxMore = i.getStringExtra("wxmore");
        for (String[] x : new String[][] {{"sunrise", sunrise}, {"prayerbar", prayerBar}, {"wxmore", wxMore}})
            if (x[1] != null && !"on".equals(x[1]) && !"off".equals(x[1])) return "error: " + x[0] + " is one of on off";
        String months = i.getStringExtra("months");
        if (months != null && !"default".equals(months) && !"levant".equals(months)) return "error: months is one of default levant";
        String occasion = i.getStringExtra("occasion"), nightDim = i.getStringExtra("nightdim"), tasksPill = i.getStringExtra("taskspill");
        String backSaver = i.getStringExtra("backsaver");
        for (String[] x : new String[][] {{"occasion", occasion}, {"nightdim", nightDim}, {"taskspill", tasksPill}, {"backsaver", backSaver}})
            if (x[1] != null && !"on".equals(x[1]) && !"off".equals(x[1])) return "error: " + x[0] + " is one of on off";
        String verse = i.getStringExtra("verse");
        if (verse != null && !QuoteEvery.valid(verse)) return "error: verse is one of day 3";
        String verseKind = i.getStringExtra("versekind");
        if (verseKind != null && !VerseKind.valid(verseKind)) return "error: versekind is one of both verse hadith";
        String seconds = i.getStringExtra("seconds");
        if (seconds != null && !"on".equals(seconds) && !"off".equals(seconds)) return "error: seconds is one of on off";
        String backExit = i.getStringExtra("backexit");
        if (backExit != null && !HomeExit.valid(backExit)) return "error: backexit is one of press hold three";
        String greeting = i.getStringExtra("greeting");
        if (greeting != null && !"on".equals(greeting) && !"off".equals(greeting))
            return "error: greeting is one of on off";
        String matchApp = i.getStringExtra("matchapp");   // 4.3 «تطبيق المباريات»: auto, none or an app's package
        if (matchApp != null && !Prefs.matchAppOk(matchApp)) return "error: matchapp is auto, none or an app's package name";
        String pillsHidden = i.getStringExtra("pillshidden");   // the home's quick buttons to hide: markets, matches, center (comma list), or none
        if (pillsHidden != null && !"none".equals(pillsHidden)) {
            for (String k : pillsHidden.split(",")) if (!java.util.Arrays.asList(Prefs.QUICK_BUTTONS).contains(k)) return "error: pillshidden is none or a list of " + android.text.TextUtils.join(" ", Prefs.QUICK_BUTTONS);
        }
        String homePhotos = i.getStringExtra("homephotos");   // 4.3: the home's wallpaper uses the screensaver's packs (same, the default) or a set of its own (own)
        if (homePhotos != null && !"same".equals(homePhotos) && !"own".equals(homePhotos)) return "error: homephotos is one of same own";
        String homePacks = i.getStringExtra("homepacks");   // the home's own packs (ids, comma separated, or none), used while homephotos is own
        if (homePacks != null && !"none".equals(homePacks)) for (String id : homePacks.split(",")) if (!PhotoPacks.validId(id)) return "error: homepacks is none or pack ids separated by commas";
        String homeOurs = i.getStringExtra("homeours");
        if (homeOurs != null && !"on".equals(homeOurs) && !"off".equals(homeOurs)) return "error: homeours is one of on off";
        String homeMine = i.getStringExtra("homemine");   // «صوري» for the home alone: with ours (mix), only, none (off), or as the screensaver's (same, the default)
        if (homeMine != null && !"same".equals(homeMine) && !"mix".equals(homeMine) && !"only".equals(homeMine) && !"off".equals(homeMine)) return "error: homemine is one of same mix only off";
        String albumMode = i.getStringExtra("albummode");   // «ألبوم صوري»: a photo every few seconds (seconds, the default) or one a minute
        if (albumMode != null && !"seconds".equals(albumMode) && !"ten".equals(albumMode) && !"minute".equals(albumMode)) return "error: albummode is one of seconds ten minute";
        String clearText = i.getStringExtra("cleartext");   // «نص أوضح»
        if (clearText != null && !"on".equals(clearText) && !"off".equals(clearText)) return "error: cleartext is one of on off";
        String glowMode = i.getStringExtra("glow");   // «توهّج لون التطبيق»
        if (glowMode != null && !"off".equals(glowMode) && !"light".equals(glowMode) && !"on".equals(glowMode)) return "error: glow is one of off light on";
        String albumTitle = i.getStringExtra("albumtitle");
        if (albumTitle != null && !"on".equals(albumTitle) && !"off".equals(albumTitle)) return "error: albumtitle is one of on off";
        String albumFit = i.getStringExtra("albumfit");
        if (albumFit != null && !"fit".equals(albumFit) && !"fill".equals(albumFit)) return "error: albumfit is one of fit fill";
        String albumSize = i.getStringExtra("albumsize");
        if (albumSize != null && !"normal".equals(albumSize) && !"tall".equals(albumSize)) return "error: albumsize is one of normal tall";
        String albumDate = i.getStringExtra("albumdate");
        if (albumDate != null && !"on".equals(albumDate) && !"off".equals(albumDate)) return "error: albumdate is one of on off";
        String listenPill = i.getStringExtra("listenpill");
        if (listenPill != null && !"on".equals(listenPill) && !"off".equals(listenPill))
            return "error: listenpill is one of on off";
        String watchNext = i.getStringExtra("watchnext");
        if (watchNext != null && !"on".equals(watchNext) && !"off".equals(watchNext))
            return "error: watchnext is one of on off";
        String pagesDark = i.getStringExtra("pagesdark");
        if (pagesDark != null && !"on".equals(pagesDark) && !"off".equals(pagesDark))
            return "error: pagesdark is one of on off";
        String updateBell = i.getStringExtra("updatebell");
        if (updateBell != null && !"on".equals(updateBell) && !"off".equals(updateBell))
            return "error: updatebell is one of on off";
        String appearance = i.getStringExtra("appearance");
        if (appearance != null && !Arrays.asList(Prefs.APPEARANCES).contains(appearance))
            return "error: appearance is one of " + Prefs.join(Arrays.asList(Prefs.APPEARANCES), " ");
        String look = i.getStringExtra("look");
        if (look != null && !Arrays.asList(GlassStyle.LOOKS).contains(look))
            return "error: look is one of " + Prefs.join(Arrays.asList(GlassStyle.LOOKS), " ");
        String accentX = i.getStringExtra("accent");   // 4.3 «اللون والتحكم»
        if (accentX != null && !"default".equals(accentX)) { boolean known = false; for (String[] a : GlassStyle.ACCENTS) known |= a[0].equals(accentX); if (!known) return "error: accent is default or one of amber gold green teal sky violet rose coral"; }
        String barX = i.getStringExtra("baropacity"), dimX = i.getStringExtra("walldim");
        if (barX != null && !barX.matches("(100|[3-9][0-9])")) return "error: baropacity is a number from 30 to 100";
        if (dimX != null && !dimX.matches("([0-9]|[1-8][0-9]|90)")) return "error: walldim is a number from 0 to 90";
        String focusX = i.getStringExtra("focusstyle");
        if (focusX != null && !Arrays.asList(GlassStyle.FOCUS_STYLES).contains(focusX)) return "error: focusstyle is one of solid frame glow";
        String syncX = i.getStringExtra("looksync"), surfaceX = i.getStringExtra("surface");   // 4.3 «توحيد المظهر»: on|off, and one surface's own "quick:70:look" (used while it is off)
        if (syncX != null && !"on".equals(syncX) && !"off".equals(syncX)) return "error: looksync is one of on off";
        String[] surfaceP = surfaceX == null ? null : surfaceX.split(":", -1);
        if (surfaceP != null && !(surfaceP.length == 3 && Arrays.asList(GlassStyle.SURFACES).contains(surfaceP[0]) && surfaceP[1].matches("(100|[3-9][0-9])") && Arrays.asList(GlassStyle.FILLS).contains(surfaceP[2])))
            return "error: surface is quick|cards|tray, a number from 30 to 100, and one of look glass graphite";
        String homeLayout = i.getStringExtra("homelayout");
        if (homeLayout != null && !Arrays.asList(Prefs.HOME_LAYOUTS).contains(homeLayout))
            return "error: homelayout is one of " + Prefs.join(Arrays.asList(Prefs.HOME_LAYOUTS), " ");
        String favBar = i.getStringExtra("favbar");
        if (favBar != null) favBar = Prefs.favBarFix(favBar);   // kept as is since 4.3.1: 9 and 10 are whole sizes again
        if (favBar != null && !Arrays.asList(Prefs.FAV_BARS).contains(favBar))
            return "error: favbar is one of " + Prefs.join(Arrays.asList(Prefs.FAV_BARS), " ");
        String rating = i.getStringExtra("minrating");
        if (rating != null && !Arrays.asList(Prefs.MIN_RATINGS).contains(rating))
            return "error: minrating is one of " + Prefs.join(Arrays.asList(Prefs.MIN_RATINGS), " ");
        String photos = i.getStringExtra("photos");
        String photosWhy = photos == null ? null : PhotoInterval.refuse(photos, Prefs.ramMb(c));   // 30s only on a TV with 2 GB
        if (photosWhy != null) return photosWhy;
        String digits = i.getStringExtra("digits");
        if (digits != null && !isChoice(Prefs.DIGITS, digits))
            return "error: digits is one of " + choices(Prefs.DIGITS);
        String clock24 = i.getStringExtra("clock24");
        if (clock24 != null && !ClockSetting.valid(clock24))
            return "error: clock24 is one of on off";
        String ramtier = i.getStringExtra("ramtier");
        if (ramtier != null && !"auto".equals(ramtier) && Prefs.ramNamed(ramtier) < 0)
            return "error: ramtier is one of low mid normal auto";
        String lang = i.getStringExtra("lang");
        if (lang != null && !Tr.valid(lang))
            return "error: lang is one of ar en";
        String national = i.getStringExtra("national");
        if (national != null && !isChoice(Prefs.NATIONAL, national))
            return "error: national is one of " + choices(Prefs.NATIONAL);
        String cardStyle = i.getStringExtra("cardstyle");
        if (cardStyle != null && !isChoice(Prefs.CARD_STYLES, cardStyle))
            return "error: cardstyle is one of " + choices(Prefs.CARD_STYLES);
        String mkStyle = i.getStringExtra("mkstyle");
        if (mkStyle != null && !isChoice(Prefs.MK_STYLES, mkStyle))
            return "error: mkstyle is one of " + choices(Prefs.MK_STYLES);
        String stkChg = i.getStringExtra("stkchg");
        if (stkChg != null && !isChoice(Prefs.STK_CHG, stkChg))
            return "error: stkchg is one of " + choices(Prefs.STK_CHG);
        String mkBar = i.getStringExtra("mkbar");
        if (mkBar != null && !"on".equals(mkBar) && !"off".equals(mkBar))
            return "error: mkbar is one of on off";
        String clockSize = i.getStringExtra("clocksize");
        if (clockSize != null && !isChoice(Prefs.CLOCK_SIZES, clockSize))
            return "error: clocksize is one of " + choices(Prefs.CLOCK_SIZES);
        List<String> markets = codes(i.getStringExtra("markets"), Prefs.MARKETS);
        if (markets != null) {
            if (markets.contains(null)) return "error: markets are " + names(Prefs.MARKETS);
            if (markets.isEmpty() || markets.size() > Prefs.MAX_MARKETS || new java.util.HashSet<>(markets).size() != markets.size())
                return "error: markets is 1 to " + Prefs.MAX_MARKETS + " different ones of " + names(Prefs.MARKETS);
        }
        List<String> stocks = null;
        if (i.getStringExtra("stocks") != null) {
            stocks = new ArrayList<>();
            for (String s : i.getStringExtra("stocks").split(",")) {
                s = s.trim().toUpperCase(java.util.Locale.ROOT);
                if (s.isEmpty()) continue;
                if (!s.matches(Prefs.STOCK_PATTERN) || stocks.contains(s))
                    return "error: stocks are 4-digit Tadawul codes or US tickers, each once, e.g. 2222,1120,AAPL";
                stocks.add(s);
            }
            if (stocks.isEmpty() || stocks.size() > Prefs.MAX_STOCKS)
                return "error: stocks is 1 to " + Prefs.MAX_STOCKS + " codes or tickers";
        }
        String slot = i.getStringExtra("slot");
        if (slot != null && !isChoice(Prefs.SLOTS, slot))
            return "error: slot is one of " + choices(Prefs.SLOTS);
        String cd = i.getStringExtra("countdown"), cdName = i.getStringExtra("cdname");
        if (cd != null && !"clear".equals(cd) && !isDate(cd))
            return "error: countdown is a date like 2026-12-01, or clear";
        if (cdName != null && cd == null) return "error: cdname goes with countdown DATE";
        if (cdName != null && cdName.length() > 40) return "error: cdname is at most 40 characters";
        String idle = i.getStringExtra("idle");
        if (idle != null) {
            if (!Arrays.asList(Prefs.IDLE_MINUTES).contains(idle))
                return "error: idle is one of " + Prefs.join(Arrays.asList(Prefs.IDLE_MINUTES), " ");
            if (!Prefs.canWriteSettings(c))
                return "error: idle not allowed: this app may not change system settings on this TV"
                    + " (the TV's own screensaver settings can, or the shell: settings put system screen_off_timeout)";
        }
        List<String> genres = codes(i.getStringExtra("genres"), Prefs.GENRES);
        List<String> langs = codes(i.getStringExtra("langs"), Prefs.LANGS);
        if (genres != null && genres.contains(null)) return "error: genres are " + names(Prefs.GENRES);
        if (langs != null && langs.contains(null)) return "error: langs are " + names(Prefs.LANGS);
        List<String> events = codes(i.getStringExtra("events"), Prefs.EVENTS);
        if (events != null && events.contains(null)) return "error: events are " + names(Prefs.EVENTS);
        List<String> leagues = null;
        if (i.getStringExtra("leagues") != null) {
            leagues = new ArrayList<>();
            for (String s : i.getStringExtra("leagues").split(",")) {
                if (s.trim().isEmpty()) continue;
                if (s.trim().matches("id\\d{1,6}")) {   // 4.3 a catalogue league by its TheSportsDB id (the page names it from its games)
                    if (!leagues.contains(s.trim())) leagues.add(s.trim());
                    continue;
                }
                String[] l = Prefs.leagueByName(s);
                if (l == null) return "error: leagues are (English or Arabic name) " + names(Prefs.LEAGUES) + ", or a catalogue league's id as id4719";
                if (!leagues.contains(l[0])) leagues.add(l[0]);
            }
            if (leagues.size() > Prefs.MAX_LEAGUES) return "error: at most " + Prefs.MAX_LEAGUES + " leagues";
        }

        if (idle != null) {   // first: a refusal here leaves everything else unsaved
            try {
                if (!Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, Integer.parseInt(idle) * 60000))
                    return "error: idle not allowed: the TV did not take the change";   // S11: putInt says false when it was not written
            } catch (SecurityException e) {
                return "error: idle not allowed: the TV refused the change";
            }
        }
        if (city != null) p.setCity(city[0], city[1], city[2], tz == null ? "" : tz, cityCountry);
        if (teams != null) p.setList("teams", teams);
        if (panel != null) p.setPanel(panel);
        if (panel2 != null) p.setPanel2(panel2);
        if (homeCards != null) p.setHomePanels(homeCards);
        if (greeting != null) p.setGreeting("on".equals(greeting));
        if (listenPill != null) p.setListenPill("on".equals(listenPill));
        if (pillsHidden != null) p.setPillsHidden(pillsHidden);
        if (matchApp != null) p.setMatchApp(matchApp);
        if (homePhotos != null) p.setHomePhotosSame("same".equals(homePhotos));
        if (homePacks != null) p.setHomePacksOn("none".equals(homePacks) ? new java.util.LinkedHashSet<String>() : PhotoPacks.parseOn(homePacks));
        if (homeOurs != null) p.setHomeOursOn("on".equals(homeOurs));
        if (homeMine != null) p.setHomeMine("same".equals(homeMine) ? null : homeMine);
        if (albumMode != null) p.setAlbumMode(albumMode);
        if (albumTitle != null) p.setAlbumTitle("on".equals(albumTitle));
        if (clearText != null) p.setClearText("on".equals(clearText));
        if (glowMode != null) p.setGlowMode(glowMode);
        if (albumFit != null) p.setAlbumFit(albumFit);
        if (albumSize != null) p.setAlbumSize(albumSize);
        if (albumDate != null) p.setAlbumDate("on".equals(albumDate));
        if (updateBell != null) p.setUpdateBell("on".equals(updateBell));
        if (watchNext != null) p.setWatchNext("on".equals(watchNext));
        if (appearance != null) p.setAppearance(appearance);
        if (look != null) p.setLook(look);
        if (accentX != null) p.setAccent("default".equals(accentX) ? "" : accentX);
        if (barX != null) p.setBarPercent(Integer.parseInt(barX));
        if (dimX != null) p.setWallDim(Integer.parseInt(dimX));
        if (focusX != null) p.setFocusStyle(focusX);
        if (syncX != null) p.setLookSync("on".equals(syncX));
        if (surfaceP != null) { int s = Arrays.asList(GlassStyle.SURFACES).indexOf(surfaceP[0]); p.setSurfacePercent(s, Integer.parseInt(surfaceP[1])); p.setSurfaceFill(s, surfaceP[2]); }
        if (homeLayout != null) p.setHomeLayout(homeLayout);
        if (favBar != null) p.setFavBar(favBar);
        if (pagesDark != null) p.setPagesDark("on".equals(pagesDark));
        if (adhanBar != null) p.setAdhanBar("on".equals(adhanBar));
        if (updateChannel != null && !updateChannel.equals(p.updateChannel())) {   // another release now: the number shown as the newest is read again
            p.setUpdateChannel(updateChannel);
            Updater.refreshLatestAsync(c);
        }
        if (yearStrip != null) p.setYearStrip("on".equals(yearStrip));
        if (sunrise != null) p.setSunrise("on".equals(sunrise));
        if (prayerBar != null) p.setPrayerBar("on".equals(prayerBar));
        if (wxMore != null) p.setWxMore("on".equals(wxMore));
        if (months != null) p.setMonths(months);
        if (verse != null) p.setQuoteEvery(verse);
        if (verseKind != null) p.setVerseKind(verseKind);
        if (seconds != null) p.setSeconds("on".equals(seconds));
        if (backExit != null) p.setHomeExit(backExit);
        if (occasion != null) p.setOccasion("on".equals(occasion));
        if (nightDim != null) p.setNightDim("on".equals(nightDim));
        if (tasksPill != null) p.setTasksPill("on".equals(tasksPill));
        if (backSaver != null) p.setBackSaver("on".equals(backSaver));
        if (prayerMethod != null) p.setPrayerMethod(PrayerMethod.parse(prayerMethod));
        if (adj != null) p.setPrayerAdj(adj);
        if (hijriOffset != null) p.setHijriOffset(hijriOffset);
        if (prayerAdj != null) p.setPrayerAdjOn("on".equals(prayerAdj));
        if (rating != null) p.setMinRating(rating);
        if (photos != null) p.setPhotoMinutes(photos);
        if (digits != null) p.setDigits(digits);
        if (clock24 != null) p.setClock24("on".equals(clock24));
        if (ramtier != null) p.setRamTier(ramtier);
        if (lang != null) p.setLang(lang);
        if (national != null) p.setNational(national);
        if (cardStyle != null) p.setCardStyle(cardStyle);
        if (mkStyle != null) p.setMkStyle(mkStyle);
        if (markets != null) p.setMarkets(markets);
        if (mkBar != null) p.setMarketsOn("on".equals(mkBar));
        if (clockSize != null) p.setClockSize(clockSize);
        if (stocks != null) p.setStocks(stocks);
        if (stkChg != null) p.setStkChg(stkChg);
        if (slot != null) p.setSlot(slot);
        if (cd != null) {
            if ("clear".equals(cd)) p.setCountdown("", "");
            else p.setCountdown(cd, cdName == null ? "" : cdName.trim());
        }
        if (genres != null) p.setList("genres", genres);
        if (langs != null) p.setList("langs", langs);
        if (events != null) p.setList("events", events);
        if (leagues != null) p.setList("leagues", leagues);
        // the page reads its settings once, when it starts: a screensaver (or preview) already on the screen would go on showing the old ones
        c.sendBroadcast(new Intent(Prefs.CHANGED).setPackage(c.getPackageName()));
        return "saved\n" + describe(c, p);
    }

    /** «المهام»: n is the number list shows (from 1, done ones included). */
    private static String tasks(Context c, Prefs p, Intent i) {
        String op = String.valueOf(i.getStringExtra("op"));
        switch (op) {
            case "list":
                return listing(p);
            case "add": {
                String at = i.getStringExtra("at");
                String why;
                if (at == null) why = p.addTask(i.getStringExtra("text"));
                else {
                    long due = Reminders.parse(at, Reminders.zone(p.cityTz()));   // the date and time in the TV's own city
                    if (due < 0) return "error: --at is a date and time like 2026-11-05 17:00";
                    int before = i.getIntExtra("before", 0), where = "saver".equals(i.getStringExtra("where")) ? 1 : "home".equals(i.getStringExtra("where")) ? 2 : 0;
                    if (before != Reminders.beforeOf(before)) return "error: --before is 0, 10, 30 or 60 minutes";
                    why = p.addReminder(i.getStringExtra("text"), due, before, Reminders.repeatOf(i.getStringExtra("repeat")), "on".equals(i.getStringExtra("sound")), where);
                    if (why == null) c.sendBroadcast(new Intent(Prefs.CHANGED).setPackage(c.getPackageName()));   // a screen that is up starts over with it
                }
                return why != null ? "error: " + why : "saved\n" + listing(p);
            }
            case "done":
            case "del": {
                int n = i.getIntExtra("n", 0);
                boolean ok = "done".equals(op) ? p.doneTask(n) : p.deleteTask(n);
                return !ok ? "error: no task number " + n + " (list shows the numbers)"
                    : "saved\n" + listing(p);
            }
            case "clear":
                p.clearTasks();
                return "saved\nno tasks";
            default:
                return "error: op is one of list add done del clear";
        }
    }

    /** «صوري»: n is the number list shows (from 1). */
    private static String photos(Context c, Prefs p, Intent i) {
        String op = String.valueOf(i.getStringExtra("op"));
        switch (op) {
            case "list":
                return photoListing(c, p);
            case "add": {
                String path = i.getStringExtra("path");
                java.io.File src = Own.incoming(c);
                if (path != null) {
                    if (!path.matches("/data/local/tmp/urtv-own/[A-Za-z0-9_.-]+") || path.contains(".."))
                        return "error: path must be a file in /data/local/tmp/urtv-own/";
                    src = new java.io.File(path);
                }
                // 4.3 S11: `--es size 123` is a string, which getIntExtra reads as «none» and would skip the check: refused instead
                Object given = i.getExtras() == null ? null : i.getExtras().get("size");
                if (given != null && !(given instanceof Integer)) {
                    if (src.equals(Own.incoming(c))) src.delete();
                    return "error: size must be a number (--ei size BYTES)";
                }
                int size = i.getIntExtra("size", -1);   // what the shell sent: a short or stale file is refused
                String why = size >= 0 && src.length() != size ? "the file is not the one sent (" + src.length() + " of " + size + " bytes)"
                    : Own.add(c, src);
                if (why != null && src.equals(Own.incoming(c))) src.delete();
                return why != null ? "error: " + why : "saved\n" + photoListing(c, p);
            }
            case "del": {
                int n = i.getIntExtra("n", 0);
                return !Own.delete(c, n) ? "error: no photo number " + n + " (list shows the numbers)"
                    : "saved\n" + photoListing(c, p);
            }
            case "clear":
                Own.clear(c);
                return "saved\n" + photoListing(c, p);
            case "mode": {
                String m = i.getStringExtra("mode");
                if (!Own.MIX.equals(m) && !Own.ONLY.equals(m) && !Own.ALBUM.equals(m)) return "error: mode is mix, only or album";
                p.setOwnMode(m);
                p.bumpOwnRev();
                return "saved\n" + photoListing(c, p);
            }
            default:
                return "error: op is one of list add del clear mode";
        }
    }

    private static String photoListing(Context c, Prefs p) {
        int n = Own.count(c);
        StringBuilder b = new StringBuilder("photos: " + n + " of " + Own.max(c) + "\nmode: " + p.ownMode());
        if (n == 0) b.append(" (no photos: ours only)");
        else if (Own.ALBUM.equals(Own.mode(c))) b.append(" (only the album card shows them)");
        else if (!Own.ONLY.equals(Own.mode(c))) b.append(" (they join ours)");
        else b.append(" (only theirs)");
        for (int k = 1; k <= n; k++) b.append('\n').append(k).append(". ").append(Own.describe(c, k));
        return b.toString();
    }

    /** " @ 2026-11-05 17:00 (30 min before, daily, chime)" for a task with a reminder, nothing for one without */
    private static String reminderNote(Task t, java.util.TimeZone tz) {
        if (t.due <= 0) return "";
        List<String> more = new ArrayList<>();
        if (t.before > 0) more.add(t.before + " min before");
        if (t.repeat != Reminders.NO) more.add(Reminders.repeatName(t.repeat));
        if (t.sound) more.add("chime");
        return " @ " + Reminders.format(t.due, tz) + (more.isEmpty() ? "" : " (" + Prefs.join(more, ", ") + ")");
    }

    private static String listing(Prefs p) {
        java.util.TimeZone tz = Reminders.zone(p.cityTz());
        List<Task> all = p.tasks();
        if (all.isEmpty()) return "no tasks";
        StringBuilder b = new StringBuilder();
        for (int k = 0; k < all.size(); k++)
            b.append(k + 1).append(all.get(k).done ? ". [done] " : ". ").append(all.get(k).text).append(reminderNote(all.get(k), tz)).append('\n');
        return b.toString().trim();
    }

    private static String describe(Context c, Prefs p) {
        String[] city = p.city();
        String latest = p.latestVersion();   // what Updater last saw on the release of the current channel
        int newest = Versions.buildOf(latest);
        return "version: " + Versions.displayEn(BuildConfig.MARKETING, BuildConfig.VERSION_CODE)
            + (newest >= 0 ? " (newest: " + Versions.otherEn(BuildConfig.MARKETING, newest) + ("next".equals(p.updateChannel()) ? ", on the next channel" : p.betaOn() ? ", on the beta channel" : "") + ")" : "")
            + "\ncity: " + city[0] + " (" + city[1] + ", " + city[2] + ")"
            + "\ntimezone: " + p.cityTz()
            + "\ncountry: " + p.cityCountry()
            + "\nteams: " + Prefs.join(p.teams(), ", ")
            + "\npanel: " + p.panel() + "\npanel2: " + p.panel2()
            + "\nhome_panel: " + p.homePanel()
            + "\ngreeting: " + (p.greeting() ? "on" : "off")
            + "\nlistenpill: " + (p.listenPill() ? "on" : "off")
            + "\nhomephotos: " + (p.homePhotosSame() ? "same" : "own") + "\nhomepacks: " + (p.homePacksOn().isEmpty() ? "none" : PhotoPacks.joinOn(p.homePacksOn())) + "\nhomeours: " + (p.homeOursOn() ? "on" : "off") + "\nhomemine: " + (p.homeMine() == null ? "same" : p.homeMine()) + "\nalbummode: " + p.albumMode() + "\nalbumdate: " + (p.albumDate() ? "on" : "off") + "\nalbumtitle: " + (p.albumTitle() ? "on" : "off") + "\nalbumfit: " + p.albumFit() + "\nalbumsize: " + p.albumSize() + "\ncleartext: " + (p.clearText() ? "on" : "off") + "\nglow: " + p.glowMode()
            + "\npillshidden: " + (p.pillsHidden().isEmpty() ? "none" : p.pillsHidden()) + "\nmatchapp: " + p.matchApp()
            + "\nupdatebell: " + (p.updateBell() ? "on" : "off")
            + "\nwatchnext: " + (p.watchNext() ? "on" : "off")
            + "\nappearance: " + p.appearance()
            + "\nlook: " + p.look()
            + "\naccent: " + (p.accent().isEmpty() ? "default" : p.accent()) + "\nbaropacity: " + p.barPercent() + "\nwalldim: " + p.wallDim() + "\nfocusstyle: " + p.focusStyle()
            + "\nlooksync: " + (p.lookSync() ? "on" : "off") + "\nsurface quick: " + p.surfacePercent(0) + " " + p.surfaceFill(0) + "\nsurface cards: " + p.surfacePercent(1) + " " + p.surfaceFill(1) + "\nsurface tray: " + p.surfacePercent(2) + " " + p.surfaceFill(2)
            + "\nhomelayout: " + p.homeLayout()
            + "\nfavbar: " + p.favBar()
            + "\npagesdark: " + (p.pagesDark() ? "on" : "off")
            + "\nadhanbar: " + (p.adhanBar() ? "on" : "off")
            + "\nupdatechannel: " + p.updateChannel()
            + "\nyearstrip: " + (p.yearStrip() ? "on" : "off")
            + "\nsunrise: " + (p.sunrise() ? "on" : "off") + "\nprayerbar: " + (p.prayerBar() ? "on" : "off")
            + "\nwxmore: " + (p.wxMore() ? "on" : "off") + "\nmonths: " + p.months() + "\nverse: " + p.quoteEvery()
            + "\nversekind: " + p.verseKind() + "\nseconds: " + (p.seconds() ? "on" : "off") + "\nbackexit: " + p.homeExit()
            + "\noccasion: " + (p.occasion() ? "on" : "off") + "\nnightdim: " + (p.nightDim() ? "on" : "off") + "\ntaskspill: " + (p.tasksPill() ? "on" : "off")
            + "\nbacksaver: " + (p.backSaver() ? "on" : "off")
            + "\nprayermethod: " + p.prayerMethod()
            + "\nprayeradj: " + (p.prayerAdjOn() ? "on" : "off") + " " + PrayerAdj.describe(p.prayerAdj())
            + "\nhijrioffset: " + HijriOffset.describe(p.hijriOffset())
            + "\nminrating: " + p.minRating()
            + "\nphotos: " + p.photoMinutes() + (PhotoInterval.fast(Prefs.ramMb(c)) ? "" : " (30s needs 2 GB; " + Prefs.ramMb(c) + " MB here)")
            + "\ndigits: " + p.digits()
            + "\nclock24: " + ClockSetting.describe(p.clock24())
            + "\nramtier: " + p.ramTierSetting() + " (in use: " + new String[] {"low", "mid", "normal"}[Prefs.ramTier(c)] + ")"
            + "\nlang: " + p.lang()
            + "\nnational: " + p.national()
            + "\ncardstyle: " + p.cardStyle()
            + "\nmarkets: " + (p.marketsOn() ? "" : "off ") + Prefs.join(p.markets(), ",") + "\nclocksize: " + p.clockSize() + "\nmkstyle: " + p.mkStyle()
            + "\nstocks: " + Prefs.join(p.stocks(), ",") + "\nstkchg: " + p.stkChg()
            + "\nslot: " + p.slot()
            + "\ncountdown: " + (p.countdownDate().isEmpty() ? "none" : p.countdownDate() + " " + p.countdownName())
            + "\nidle: " + idle(Prefs.idleMs(c))
            + "\ngenres: " + Prefs.join(p.list("genres"), ",") + "\nlangs: " + Prefs.join(p.list("langs"), ",")
            + "\nevents: " + Prefs.join(p.list("events"), ",")
            + "\nleagues: " + Prefs.join(p.leagues(), ",")
            + "\nautoupdate: " + p.autoUpdate();
    }

    /** minutes the TV waits before the screensaver, "unknown" when it does not say */
    private static String idle(long ms) {
        if (ms <= 0) return "unknown";
        return ms % 60000 == 0 ? String.valueOf(ms / 60000) : (ms / 1000) + "s";
    }

    /** a real calendar date written YYYY-MM-DD */
    private static boolean isDate(String v) {
        if (!v.matches("\\d{4}-\\d{2}-\\d{2}")) return false;
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        f.setLenient(false);
        ParsePosition pos = new ParsePosition(0);
        return f.parse(v, pos) != null && pos.getIndex() == v.length();
    }

    private static boolean isChoice(String[][] all, String v) {
        for (String[] x : all) if (x[0].equals(v)) return true;
        return false;
    }

    private static String choices(String[][] all) {
        List<String> out = new ArrayList<>();
        for (String[] x : all) out.add(x[0]);
        return Prefs.join(out, " ");
    }

    private static boolean isPanel(String v) {
        for (String[] x : Prefs.PANELS) if (x[0].equals(v)) return true;
        return false;
    }

    private static String panels() {
        return names(Prefs.PANELS);
    }

    private static String names(String[][] table) {
        List<String> out = new ArrayList<>();
        for (String[] x : table) out.add(x[0]);
        return Prefs.join(out, " ");
    }

    /** "Drama,Comedy" -> the same codes, checked against the table; null entry = unknown; "" = all. */
    private static List<String> codes(String raw, String[][] table) {
        if (raw == null) return null;
        List<String> out = new ArrayList<>();
        for (String s : raw.split(",")) {
            s = s.trim();
            if (s.isEmpty()) continue;
            String hit = null;
            for (String[] x : table) if (x[0].equalsIgnoreCase(s)) hit = x[0];
            out.add(hit);
        }
        return out;
    }
}
