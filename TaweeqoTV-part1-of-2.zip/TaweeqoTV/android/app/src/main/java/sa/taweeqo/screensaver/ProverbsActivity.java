package sa.taweeqo.screensaver;

/** «كمّل المثل»: نصف مثل شعبي، والفرق تختار نصه الثاني (CultureQuizActivity) */
public class ProverbsActivity extends CultureQuizActivity {
    @Override protected String id() { return "proverbs"; }
    @Override protected CultureQuiz.Item[] deck() { return CultureQuiz.PROVERBS; }
}
