package sa.taweeqo.screensaver;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * «الألعاب»: the hub's games window opens this list, in the «ورقة» look of the games (docs/GAMES-KIT.md). The tiles come from GameRegistry, four to a line:
 * a ready game opens with one press (its ready screen has «ابدأ» focused, so a round starts in two presses); the others say «قريبًا». The games are played
 * with one remote and no phones; only «الأسرع» needs phones and says so («بالجوالات»). The focus starts on the game played last, else on the first game
 * with no phones. Back returns to the hub.
 */
public class QuizGamesActivity extends Activity {
    /** the registry's words, marked for the English table (GameRegistry has no S in it; tests/games_kit_test.py keeps the two the same) */
    static final String[] WORDS = {
        S.n("الأسرع"), S.n("الكل يجاوب من جواله، والأسرع يكسب"),
        S.n("خمس خانات"), S.n("حرف واحد، وخانة لكل من حيوان ونبات وجماد وبلاد واسم"),
        S.n("الكلمة المفقودة"), S.n("جملة ناقصة كلمة، من يكملها؟"),
        S.n("واحد مو معنا"), S.n("الكل يعرف الكلمة إلا واحد، من هو؟"),
        S.n("بدون كلام"), S.n("مثّل الكلمة وفريقك يخمّنها"),
        S.n("خلية الحروف"), S.n("فريقان يتسابقان على وصل الخلية"),
        S.n("خمّن الكلمة"), S.n("كلمة من خمسة حروف في ست محاولات"),
        S.n("دومينو"), S.n("الدومينو كما تعرفونه، بالريموت"),
        S.n("كمّل المثل"), S.n("نص مثل شعبي، وعليكم تكملونه"),
        S.n("وش معناها؟"), S.n("كلمة من لهجاتنا، وش معناها؟"),
        S.n("صح ولا خطأ"), S.n("معلومات عن السعودية وتراثها"),
    };
    /**
     * «كيف نلعب؟»: طويقو يشرح كل لعبة في أربع خطوات قبل ما تبدأ، بنفس ترتيب GameRegistry.ALL (لعبة لكل سطر). OK على اللعبة يفتح الشرح و«ابدأ اللعبة»
     * عليه التركيز، فاللعبة تبدأ بضغطتين مثل قبل؛ «رجوع» يقفل الشرح.
     */
    static final String[][] HOW = {
        {S.n("امسحوا الرمز اللي على الشاشة بكاميرا الجوال"), S.n("كل واحد يكتب اسمه في جواله"), S.n("السؤال على التلفزيون، والجواب تختاره من جوالك"), S.n("الصح والأسرع ياخذ نقاط أكثر")},
        {S.n("يطلع لكم حرف على الشاشة"), S.n("اكتبوا حيوان ونبات وجماد وبلاد واسم تبدأ بالحرف"), S.n("أول من يخلّص يقول «خلّصنا» وصاحب الريموت يضغط OK"), S.n("قولوا إجاباتكم، وصاحب الريموت يعطي كل فريق نقاطه")},
        {S.n("تطلع جملة ناقصة كلمة"), S.n("الفريق اللي عليه الدور يقول الكلمة بصوت عالي"), S.n("اضغطوا OK عشان تنكشف الكلمة"), S.n("اختاروا «صح» أو «خطأ» والنقاط تنحسب لحالها")},
        {S.n("الريموت يدور عليكم، وكل واحد يشوف كلمته والباقين يغطّون عيونهم"), S.n("الكل عنده نفس الكلمة إلا واحد ما يعرفها"), S.n("كل واحد يقول جملة عن الكلمة بدون ما يفضحها"), S.n("بعدها أشّروا على اللي تشكّون إنه برا السالفة")},
        {S.n("الممثل ياخذ الريموت ويشوف الكلمة لحاله"), S.n("مثّلها بدون كلام، وفريقك يخمّنها قبل ما يخلص الوقت"), S.n("OK إذا خمّنوها صح، والسهم اليسار عشان تتخطّاها"), S.n("الفريق اللي يجمع كلمات أكثر يفوز")},
        {S.n("فريقين، ولكل فريق جهتين متقابلتين في اللوحة"), S.n("الفريق اللي عليه الدور يختار حرف ويضغط OK"), S.n("جاوبوا السؤال بصوت عالي، وOK يكشف الجواب"), S.n("الجواب الصح ياخذ الخلية، وأول فريق يوصل جهتيه يفوز")},
        {S.n("فيه كلمة سرية من خمسة حروف، وعندكم ست محاولات"), S.n("اكتبوا كلمة بالأسهم وOK، ثم اختاروا «إدخال»"), S.n("الأخضر حرف صح بمكانه، والبرتقالي حرف موجود بس مكانه غلط"), S.n("تعاونوا كلكم وخمّنوها قبل ما تخلص المحاولات")},
        {S.n("العبوا مع أهلكم أو ضد الكمبيوتر، من ٢ إلى ٤ لاعبين"), S.n("اختر قطعة بالأسهم واضغط OK عشان تلعبها"), S.n("نص القطعة لازم يطابق طرف من طرفي السلسلة"), S.n("أول من يخلّص قطعه يكسب الجولة ونقاط اللي باقي عند غيره")},
        {S.n("نتقسّم فرق، والريموت مع الفريق اللي عليه الدور"), S.n("يطلع نص مثل شعبي وأربعة خيارات"), S.n("اختاروا النص الثاني بالأسهم واضغطوا OK"), S.n("كل جواب صح بنقطة، والفريق الأعلى يفوز")},
        {S.n("نتقسّم فرق، والريموت مع الفريق اللي عليه الدور"), S.n("تطلع كلمة من لهجاتنا وأربعة معاني"), S.n("اختاروا المعنى الصح بالأسهم واضغطوا OK"), S.n("كل جواب صح بنقطة، والفريق الأعلى يفوز")},
        {S.n("نتقسّم فرق، والريموت مع الفريق اللي عليه الدور"), S.n("تطلع معلومة عن السعودية وتراثها"), S.n("قرّروا: صح ولا خطأ، واضغطوا OK"), S.n("إذا كانت خطأ يطلع لكم الصح، وكل جواب صح بنقطة")},
    };
    static final int COLS = 4;
    private FrameLayout root; private float scale; private int sel; private Typeface display, medium, title; private GameLook L;
    /** the game whose «كيف نلعب؟» card is open (-1: none), and the card's focused button (0 «ابدأ اللعبة», 1 «رجوع») */
    private int how = -1, howSel; private boolean latin;
    /** the first of the two rows of tiles on screen (the list scrolls a row at a time when there are more than eight games) */
    private int top; static final int ROWS_SHOWN = 2;

    @Override protected void attachBaseContext(Context base) {
        Context e = S.wrap(base);
        if (S.en()) { super.attachBaseContext(e); return; }
        android.content.res.Configuration c = new android.content.res.Configuration(base.getResources().getConfiguration());
        c.setLocale(new java.util.Locale("ar")); c.setLayoutDirection(new java.util.Locale("ar"));
        super.attachBaseContext(base.createConfigurationContext(c));
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setWindowAnimations(0);
        scale = getResources().getDisplayMetrics().widthPixels / 1920f;
        L = GameLook.of(this);
        try { medium = Typeface.createFromAsset(getAssets(), GameLook.TEXT_FONT); display = Typeface.create(medium, Typeface.BOLD); }   // خط طويقو للكلام (HailElastic)
        catch (RuntimeException noHail) {
            try { display = Typeface.createFromAsset(getAssets(), "fonts/ThmanyahDisplay-Bold.otf"); medium = Typeface.createFromAsset(getAssets(), "fonts/Thmanyah-Medium.otf"); }
            catch (RuntimeException e) { display = Typeface.DEFAULT_BOLD; medium = Typeface.DEFAULT; }
        }
        try { title = Typeface.createFromAsset(getAssets(), "fonts/AsiriCandy.ttf"); } catch (RuntimeException e) { title = display; }   // خط طويقو للعناوين الكبيرة فقط
        latin = DigitsText.isLatin(new Prefs(this).digits());
        root = new FrameLayout(this);
        root.setLayoutDirection(Dir.layout());
        root.setBackgroundColor(L.paper);
        setContentView(root);
        sel = GameRegistry.firstFocus(GamePrefs.last(this));
        draw();
    }

    private int px(float v) { return Math.round(v * scale); }
    private FrameLayout.LayoutParams at(float w, float h, float x, float y) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w < 0 ? -1 : px(w), px(h), Gravity.START | Gravity.TOP);
        p.setMarginStart(px(x)); p.topMargin = px(y);
        return p;
    }
    /** the biggest size from `size` down (never under 22, design pixels) at which `s` stands in `maxLines` lines of a `w` x `h` box with no line cut */
    private float fit(Typeface face, String s, float size, float w, float h, int maxLines, float spacing) {
        android.text.TextPaint paint = new android.text.TextPaint(); paint.setTypeface(face);
        for (float f = size; f > 22; f -= 2) {
            paint.setTextSize(f * scale);
            android.text.StaticLayout lay = new android.text.StaticLayout(s, paint, Math.max(1, px(w)), android.text.Layout.Alignment.ALIGN_NORMAL, spacing, 0, false);
            if (lay.getLineCount() <= maxLines && lay.getHeight() <= px(h)) return f;
        }
        return 22;
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextColor(color); v.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * scale); v.setTypeface(bold ? display : medium);
        v.setIncludeFontPadding(false); v.setTextDirection(Dir.text()); v.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        return v;
    }

    private void draw() {
        root.removeAllViews();
        View band = new View(this); band.setBackgroundColor(L.deep);
        root.addView(band, at(-1, 200, 0, 0));
        TextView head = text(S.t("الألعاب"), 92, L.onDeep, true); head.setTypeface(title); head.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(head, at(760, 184, 96, 8));
        ImageView mascot = new ImageView(this); mascot.setImageResource(R.drawable.taweeqo_wave); mascot.setScaleType(ImageView.ScaleType.FIT_CENTER);
        mascot.setBackgroundColor(L.paper); mascot.setPadding(px(8), px(8), px(8), px(8));   // طويقو أحمر مثل الصندوق: مربّع فاتح وراه عشان يبان
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(px(176), px(184), Gravity.END | Gravity.TOP); ip.setMarginEnd(px(80)); ip.topMargin = px(8);
        root.addView(mascot, ip);
        LinearLayout talk = new LinearLayout(this); talk.setOrientation(LinearLayout.VERTICAL); talk.setLayoutDirection(Dir.layout()); talk.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        TextView hello = text(S.t("أهلًا! أنا طويقو، اختاروا لعبة وأنا أشرح لكم"), 38, L.onDeep, true); hello.setGravity(Gravity.END); hello.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        talk.addView(hello, new LinearLayout.LayoutParams(-1, -2));
        TextView mode = text(S.t("بدون جوالات: ريموت واحد يدور بينكم"), 32, L.saff, false); mode.setGravity(Gravity.END); mode.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, -2); mlp.topMargin = px(12);
        talk.addView(mode, mlp);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(px(860), px(184), Gravity.END | Gravity.TOP); mp.setMarginEnd(px(96 + 176 + 24)); mp.topMargin = px(8);
        root.addView(talk, mp);
        float w = 408, hgt = 336, gap = 32;
        int rows = (GameRegistry.ALL.length + COLS - 1) / COLS, row = sel / COLS;
        if (row < top) top = row; else if (row >= top + ROWS_SHOWN) top = row - ROWS_SHOWN + 1;
        for (int i = 0; i < GameRegistry.ALL.length; i++) {
            if (i / COLS < top || i / COLS >= top + ROWS_SHOWN) continue;
            GameRegistry.Game g = GameRegistry.ALL[i];
            boolean focus = i == sel, live = g.ready;
            int words = focus ? L.onInk : live ? L.ink : L.ink(0x80);
            LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.BOTTOM); tile.setLayoutDirection(Dir.layout());
            tile.setPadding(px(32), px(24), px(32), px(28));
            GradientDrawable bg = new GradientDrawable(); bg.setColor(focus ? L.ink : live ? L.tile : L.paper);
            if (live || focus) bg.setStroke(px(6), L.ink); else bg.setStroke(px(4), L.ink(0x59), px(14), px(10));
            tile.setBackground(bg);
            String markWord = !live ? S.t("قريبًا") : g.phones ? S.t("بالجوالات") : "";
            if (!markWord.isEmpty()) {   // the mark: a small square-cornered label at the top of the tile
                TextView mark = text(markWord, 30, live ? L.onSaff : words, true); mark.setSingleLine(true);
                if (live) mark.setBackgroundColor(L.saff);
                mark.setPadding(px(live ? 14 : 0), px(4), px(live ? 14 : 0), px(4));
                LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(-2, -2); kp.gravity = Gravity.START;
                tile.addView(mark, kp);
            }
            tile.addView(new View(this), new LinearLayout.LayoutParams(1, 0, 1f));
            // the title and the line fit the tile whatever the language: the size comes down (the title may take two lines, the line three) before anything is cut
            float inner = w - 64;
            String title = S.tv(g.name), about = S.tv(g.line);
            TextView name = text(title, fit(display, title, 56, inner, 120, 2, 1f), words, true); name.setMaxLines(2);
            tile.addView(name, new LinearLayout.LayoutParams(-1, -2));
            TextView line = text(about, fit(medium, about, 30, inner, 96, 3, 1.1f), words, false); line.setMaxLines(3); line.setLineSpacing(0, 1.1f); line.setAlpha(focus ? .9f : .8f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, px(96)); lp.topMargin = px(8);
            tile.addView(line, lp);
            root.addView(tile, at(w, hgt, 96 + (i % COLS) * (w + gap), 236 + (i / COLS - top) * (hgt + gap)));
        }
        LinearLayout hint = new LinearLayout(this); hint.setOrientation(LinearLayout.HORIZONTAL); hint.setLayoutDirection(Dir.layout());
        boolean more = top + ROWS_SHOWN < rows, less = top > 0;
        String[] kv = more || less
            ? new String[]{"◀ ▶ ▲ ▼", S.t("الألعاب"), S.t("اختيار"), S.t("الشرح والبداية"), S.t("رجوع"), S.t("الأقسام"), more ? "▼" : "▲", more ? S.t("ألعاب أكثر تحت") : S.t("ألعاب أكثر فوق")}
            : new String[]{"◀ ▶ ▲ ▼", S.t("الألعاب"), S.t("اختيار"), S.t("الشرح والبداية"), S.t("رجوع"), S.t("الأقسام")};
        for (int i = 0; i + 1 < kv.length; i += 2) {
            TextView key = text(kv[i], 30, L.ink, false); key.setGravity(Gravity.CENTER); key.setTextAlignment(View.TEXT_ALIGNMENT_CENTER); key.setBackgroundColor(L.ink(0x24)); key.setPadding(px(16), 0, px(16), 0); key.setMinWidth(px(64));
            LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(-2, px(48)); kp.setMarginEnd(px(12));
            hint.addView(key, kp);
            TextView wv = text(kv[i + 1], 32, L.ink, false); wv.setAlpha(.85f); wv.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-2, px(48)); wp.setMarginEnd(px(48));
            hint.addView(wv, wp);
        }
        root.addView(hint, at(-1, 48, 96, 978));
        if (how >= 0) drawHow();
    }

    /** «كيف نلعب؟»: طويقو جنب الشرح، أربع خطوات مرقّمة، و«ابدأ اللعبة» و«رجوع» */
    private void drawHow() {
        GameRegistry.Game g = GameRegistry.ALL[how];
        View dim = new View(this); dim.setBackgroundColor(L.ink(0xD9)); dim.setClickable(true);
        root.addView(dim, at(-1, 1080, 0, 0));
        FrameLayout card = new FrameLayout(this); card.setLayoutDirection(Dir.layout());
        GradientDrawable cb = new GradientDrawable(); cb.setColor(L.paper); cb.setStroke(px(6), L.ink); card.setBackground(cb);
        root.addView(card, at(1632, 888, 144, 96));
        View band = new View(this); band.setBackgroundColor(L.deep);
        card.addView(band, at(-1, 168, 0, 0));
        TextView ask = text(S.t("كيف نلعب؟"), 36, L.onSaff, true); ask.setBackgroundColor(L.saff); ask.setPadding(px(16), px(6), px(16), px(6)); ask.setSingleLine(true);
        card.addView(ask, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.TOP) {{ setMarginStart(px(64)); topMargin = px(24); }});
        String name = S.tv(g.name);
        TextView big = text(name, 64, L.onDeep, true); big.setTypeface(title); big.setSingleLine(true); big.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(big, at(1000, 100, 64, 68));
        ImageView mascot = new ImageView(this); mascot.setImageResource(how % 2 == 0 ? R.drawable.taweeqo_front : R.drawable.taweeqo_think); mascot.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(px(400), px(460), Gravity.END | Gravity.TOP); ip.setMarginEnd(px(56)); ip.topMargin = px(200);
        card.addView(mascot, ip);
        TextView bubble = text(S.t("أنا طويقو، وهذي طريقة اللعب:"), 40, L.deep, true);
        card.addView(bubble, at(1080, 60, 64, 200));
        String[] steps = HOW[how];
        for (int i = 0; i < steps.length; i++) {
            float y = 284 + i * 124;
            TextView no = text(DigitsText.convert(String.valueOf(i + 1), latin), 44, L.onSaff, true); no.setGravity(Gravity.CENTER); no.setTextAlignment(View.TEXT_ALIGNMENT_CENTER); no.setBackgroundColor(L.saff);
            card.addView(no, at(80, 80, 64, y));
            String line = S.en() ? S.tv(steps[i]) : DigitsText.convert(S.tv(steps[i]), latin);
            TextView st = text(line, fit(medium, line, 40, 960, 108, 2, 1.1f), L.ink, false); st.setMaxLines(2); st.setLineSpacing(0, 1.1f); st.setGravity(Gravity.CENTER_VERTICAL);
            card.addView(st, at(960, 108, 168, y - 14));
        }
        String[] labels = {S.t("ابدأ اللعبة"), S.t("رجوع")};
        for (int i = 0; i < labels.length; i++) {
            boolean f = i == howSel;
            TextView b = text(labels[i], 40, f ? L.onInk : L.ink, true); b.setGravity(Gravity.CENTER); b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            GradientDrawable bb = new GradientDrawable(); bb.setColor(f ? L.ink : L.tile); bb.setStroke(px(5), L.ink); b.setBackground(bb);
            card.addView(b, at(i == 0 ? 440 : 280, 96, 64 + i * (440 + 32), 760));
        }
    }

    /** opens the game of the open card (the old one-press path: its ready screen has «ابدأ» focused) */
    private void startGame(GameRegistry.Game g) {
        boolean opened = false;
        if (g.ready) {
            try { startActivity(new Intent().setClassName(this, getClass().getPackage().getName() + "." + g.activity)); GamePrefs.setLast(this, g.id); opened = true; }
            catch (RuntimeException notThere) { /* a game marked ready whose screen is not in this build: «قريبًا» */ }
        }
        if (!opened) Toast.makeText(this, S.t("قريبًا"), Toast.LENGTH_SHORT).show();
    }

    @Override protected void onResume() { super.onResume(); if (how >= 0) { how = -1; draw(); } }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(e);
        int k = e.getKeyCode(), n = GameRegistry.ALL.length;
        int dx = k == KeyEvent.KEYCODE_DPAD_LEFT ? -1 : k == KeyEvent.KEYCODE_DPAD_RIGHT ? 1 : 0;
        if (Dir.rtl()) dx = -dx;
        int dy = k == KeyEvent.KEYCODE_DPAD_UP ? -1 : k == KeyEvent.KEYCODE_DPAD_DOWN ? 1 : 0;
        boolean okKey = k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER || k == KeyEvent.KEYCODE_BUTTON_A;
        if (how >= 0) {   // the «كيف نلعب؟» card takes every key while it is up
            if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE) { how = -1; draw(); return true; }
            if (dx != 0 || dy != 0) { int to = Math.max(0, Math.min(1, howSel + (dx != 0 ? dx : dy))); if (to != howSel) { howSel = to; draw(); } return true; }
            if (okKey) { if (howSel == 0) startGame(GameRegistry.ALL[how]); else { how = -1; draw(); } return true; }
            return true;
        }
        if (dx != 0) { if (sel % COLS + dx >= 0 && sel % COLS + dx < COLS && sel + dx < n) { sel += dx; draw(); } return true; }
        if (dy != 0) { int to = sel + dy * COLS; if (to >= 0 && to < n) { sel = to; draw(); } return true; }
        if (okKey) {
            GameRegistry.Game g = GameRegistry.ALL[sel];
            if (!g.ready) { Toast.makeText(this, S.t("قريبًا"), Toast.LENGTH_SHORT).show(); return true; }
            how = sel; howSel = 0; draw();   // the card first; «ابدأ اللعبة» is focused, so a game still starts with two presses
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
}
