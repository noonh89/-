# Changelog

Newest first. `next` is where changes land first; a release is what was tested there.

## 4.3.6

A safety hotfix of 4.3.5: the setup never turns off the apps that open a TV's own Settings, its channels (Live TV) or the setup of its inputs.

- **إعدادات التلفزيون وقنواته ما تنطفي أبداً:** قبل ما نوقف أي تطبيق من القائمة نسأل التلفزيون نفسه أي التطبيقات تفتح «الإعدادات» والقنوات (التلفزيون المباشر) وإعداد المداخل، ونتركها شغّالة مهما قالت القائمة. وإذا ما جاوب التلفزيون، أو ما ذكر أي تطبيق للإعدادات، ما نوقف شيئاً من القائمة ونقول ليش. بعض قوائم المجتمع كانت تذكر تطبيق الإعدادات أو القنوات لبعض الطرازات (Whale OS وبعض أجهزة Vestel وBeko وGrundig وSony وغيرها)، وصارت محفوظة بالاسم أيضاً.
- **الريموت ما يعلّق على أجهزة أندرويد 8:** على جهاز OTT بأندرويد 8.0 كان الريموت يتوقف عن الاستجابة في الواجهة بعد التحديث. خدمة الكتابة من الجوال كانت تطلب كل ضغطات الريموت على هذه الأجهزة. صارت ما تطلبها أبداً تحت أندرويد 9 ولا على جهاز ما هو Android TV، وأي خطأ فيها يرجّع الزر كما هو.
- **حماية إضافية لنظام أندرويد:** `com.google.android.sdksandbox` (اسم جوجل لصندوق حماية الإعلانات في أندرويد) صار ضمن أجزاء النظام اللي ما تنطفي، مثل `com.android.sdksandbox`.

## 4.3.5

A hotfix of 4.3.4: a TV whose home kept failing at start (an LG-branded CVTE Android 9 set) was left on a black screen, and video in other apps went black after the TV had been on a while.

- **إذا طاحت الواجهة عند التشغيل ما تبقى الشاشة سوداء، ترجع للواجهة الأصلية:** إذا توقفت الواجهة أو علّقت (ما رسمت أول صورة خلال ٢٠ ثانية) مرتين بعد التشغيل خلال ١٠ دقائق، تفتح بدلها صفحة بسيطة فيها «افتح الشاشة الأصلية» و«حاول مرة ثانية»، وتترك اختيار الشاشة الرئيسية للتلفزيون من جديد. الصفحة بدون رمز الرقابة (الواجهة اللي تطيح ما تقدر تسأل عنه). صورتها: docs/mockups/safe-page.png.
- **تلفزيون بدون متصفح النظام (WebView):** كانت بطاقة الشاشة الرئيسية تنشئ WebView عند كل تشغيل، وإذا ما كان في التلفزيون WebView شغّال تطيح الواجهة كلها. صارت الواجهة تشتغل بدون البطاقة، و«المباريات» تقول إن الصفحة ما تفتح وتقفل.
- **الفيديو يطلع أسود بعد فترة:** مستخدم: بعد ما يشتغل التلفزيون فترة، أي فيديو في يوتيوب والتطبيقات الثانية يطلع أسود وما يصلحه إلا إطفاء التلفزيون وتشغيله. شاشة التوقف الكاملة («شاشة التوقف» من الرئيسية، ونهاية مؤقت النوم بدون الإضافات) كانت تبقى شغّالة خلف التطبيق ساعات على تلفزيونات الذاكرة القليلة. صارت تُقفل وتفرّغ ذاكرتها أول ما يجي تطبيق ثاني قدّامها، وصفحة شاشة التوقف توقف عدّاداتها (الساعة والصور والبطاقات والتحديثات) وهي مخفية وترجع لها أول ما تبان.
- **تقارير أوضح:** سطر «WebView:» في تقرير الإعداد وتقرير «أرسل تقرير» صار فيه اسم الحزمة ونسختها («none» إذا ما فيه). واختبار جديد يبني الواجهة على Android 9 ويتأكد إن كل شيء أحدث منه محمي بفحص النسخة.

## 4.3.4

A hotfix of 4.3.3: fixes only, from users' reports; nothing in it changes the design.

- **الريموت يعلّق (TCL):** الشاشة الرئيسية كانت تسأل تطبيق الإعدادات عن قناة التحديث على خيطها الرئيسي كل دقيقة وعند كل رجوع، وعلى TCL السؤال يشغّل التطبيق الثاني من الصفر فيتأخر الريموت. صارت تقرأ القناة من الرد اللي تجيبه أصلًا على خيط جانبي، وما تسأل على الخيط الرئيسي أبدًا. (جديد في 4.3.3.)
- **«تحديث تلفزيوني» يتخطّى صفًا:** بالريموت كان النزول يقفز فوق «تحديث صفحة شاشة التوقف»: ملاحظة الإصدار تحته كانت تنزل الصفحة لآخرها وتنقل التحديد لآخر صف، و4.3.3 حطّت «النسخ التجريبية» تحته. صارت تُظهر الملاحظة بدون ما تحرّك التحديد. (جديد في 4.3.3.)
- **الإعدادات تحتاج ضغطتين:** إذا وصل رد متأخر (مثل سؤال «UrTV النظيف» للشاشة الرئيسية، وهو بطيء على TCL) والريموت مضغوط، كانت القائمة تنبني من جديد وتضيع الضغطة الأولى. صار البناء ينتظر رفع الإصبع (ثانية بالأكثر)، والصف يأخذ ضغطته أولًا.
- **«الألعاب» تفتح الإعدادات:** من «مركز التحكم» كانت «الألعاب» ترجّع شاشة الإعدادات أو المعاينة المفتوحة من قبل بدل الألعاب. صارت تفتح «تلفزيونك» من جديد على الألعاب.
- **خيارات التطبيق مقصوصة:** الضغط المطوّل على تطبيق كان يفتح مربعًا بعرض التطبيق بالضبط، فتنقص كلمات مثل «صفحته في المتجر» و«إلغاء التثبيت». صار المربع بعرض أطول كلمة (وما يطلع برا الشاشة)، والصف يكبر مع خط التلفزيون.
- **التطبيقات المخفية:** ما كان فيه طريق واضح يرجّع تطبيقًا مخفيًا. صار في الإعدادات ← «ترتيب كل التطبيقات» خيار «التطبيقات المخفية» يفتح قائمتها مباشرة، ورسالة الإخفاء تقول هذا. وإذا تغيّر تطبيق والإعدادات مفتوحة، كان وضع التعديل يقفل بنفسه أول ما يفتح؛ صُلّح.

## 4.3.3

A small release: one new row and three small fixes; nothing else changes.

- **«النسخ التجريبية» (جديد، متوقفة افتراضيًا):** في إعدادات شاشة التوقف ← «تحديث تلفزيوني» صف جديد: «تجيك التحديثات قبل الكل بعد ما نجربها. ممكن يكون فيها أخطاء بسيطة». إذا شغّلته يقرأ «تحديث تلفزيوني» (شاشة التلفزيون وصفحة الجوال وسطر «الإصدار المتاح») الإصدار `apk-beta` بدل `apk-latest`؛ وإذا أوقفته ما يقرأ إلا `apk-latest`. إذا أوقفته وأنت على نسخة تجريبية أحدث من العادية يقول «بترجع للنسخة العادية لما توصل لنفس الرقم أو أعلى»، وما ينزل لنسخة أقدم أبدًا (نفس فحوص التوقيع والصلاحية). وللوكيل: `optimize/saver.sh updatechannel beta|latest` (و`next` للمختبر كما كان). نسخة تجريبية تُنقل لـ `apk-beta` بيد المالك فقط، من workflow جديد `promote-beta.yml` يأخذ ملفات `apk-next` الموقّعة كما هي ولا يبني شيئًا؛ ما فيه ترقية تلقائية.
- **ملاحظات النسخة التجريبية:** وأنت على «النسخ التجريبية» يظهر في «تحديث تلفزيوني» زر «أرسل ملاحظة عن النسخة التجريبية» يفتح «أرسل تقرير» (رمز QR، وتكتب كلامك من الجوال في صفحة الإرسال). وبعد تحديث تجريبي يسألك التلفزيون مرة وحدة «انت على النسخة التجريبية، إذا شفت شي غريب أرسل ملاحظة»، وإذا توقف التطبيق وأعاد التشغيل بنفسه يسأل مرة وحدة «صار خطأ، تبي ترسل تقرير؟» (يحفظ اسم نوع الخطأ فقط). التقرير فيه سطر `channel: beta` (أو `latest`) ليفرز التحليل الليلي بين النسخ. كل هذا لمن شغّل النسخ التجريبية فقط، وما يُرسل شي من التلفزيون نفسه.
- **«إنقاذ تلفزيونك» (تطبيق صغير مستقل):** لو صار شيء بعد الإعداد (زر الرئيسية ما يفتح شيئاً) تثبّت من Downloader الرابط الثابت `https://github.com/tshi-dev/UrTV/releases/download/apk-latest/urtv-rescue.apk`، تفتحه وتضغط «رجّع التلفزيون كما كان»: يشغّل الشاشة الأصلية ووسيط الإعداد ومساعديهما وكل ما أوقفه إعدادنا (الشاشة الرئيسية «تلفزيونك» تقول له، ولا يسأله غير تطبيق موقّع بمفتاحنا)، ويرجّع زر الرئيسية للشاشة الأصلية. ما يحذف شيئاً ولا يوقف شيئاً. الدليل: docs/RESCUE.md.
- **«تحقق من التحديث» مع «النسخ التجريبية»:** إذا ما فيه نسخة تجريبية منشورة (أو ما فيه أحدث من المثبّتة) كان يقول «التحديث من التلفزيون ما يشتغل على هذا الجهاز»؛ صار يقول «لا يوجد أحدث» كما في القناة العادية.
- **أسماء الأسواق (GitHub #60):** صفحة «الأسواق» في الشاشة الرئيسية صارت تعرف اسم كل رمز تذكره صفحة شاشة التوقف (مثل 4164 و4002 و4349 وغيرها) بدل أن يطلع الرقم؛ الملف `MarketNames.java` يتولّد من خريطة الصفحة نفسها.
- **تعتيم الصورة:** على بعض التلفزيونات كانت الصورة تطلع سوداء كلها لأن تعتيمها كان يقرأ لونًا كأنه شفافية؛ صار للتعتيم متغيّره الخاص `--pdim` (الأصل ٠).
- **«بدء شاشة التوقف بعد»:** إذا كتب التلفزيون ٢١٤٧٤٨٣٦٤٧ (أوقف شاشة التوقف عنده) كان الصف يقول «٢١٤٧٤٨٣ ثانية»؛ صار يقول «أبداً (التلفزيون أوقف شاشة التوقف)». والصف ما عاد يفتح إعدادات الشركة المصنّعة (ما فيها مؤقت لشاشة التوقف): سطر واحد يقول اطلب من مساعدك.
- **زر الأسواق:** صفّه «زر الأسواق» (ظاهر أو مخفي) موجود من قبل في 4.3.2، فما أضفنا شيئًا.

## 4.3.2

A light release of fixes only; nothing in it changes the design.

- **The version is named 4.3.2:** the apps' own version shows `4.3.2` (4.3.1 showed «4.3»), and the release is titled «UrTV 4.3.2». The VERSION file may now have a patch number; the numbered release's tag keeps its two-part shape (`v4.3.<build>`), so the updater and the scripts read it as before.
- **«ثبّت الجزء الثاني»:** إذا ما كان عند التلفزيون إلا الشاشة الرئيسية (Fire TV أو تثبيت Downloader)، كان «تلفزيونك» و«المدينة» و«فرقي» ما يسوون شيئًا. الحين تفتح شاشة تقول إن الجزء الثاني (الإعدادات وشاشة التوقف) غير مثبّت، وبزر واحد تنزّله من إصداراتنا وتثبّته؛ لا يُثبَّت إلا ملفنا الموقّع بمفتاحنا. وكود Downloader (2927902) مكتوب فيها لمن ما يقدر التلفزيون ينزّل.
- **«قائمتي» في الأسواق (GitHub #60):** سهم مثل 4164 (النهدي) و4002 (المواساة) و4349 (إنماء ريت الفندقي) كان يطلع رقمه و«-» بدل الاسم والسعر. السبب: الاسم وسعر كل سهم يجيان من جدول فيه أكبر ٣٠ شركة بس، وأي رمز خارجه يسأل Yahoo من التلفزيون مباشرة عن طريق وسطاء بطيئين وتفشل كثير. أضفنا للجدول ١٥ رمزًا (هذه الثلاثة ومعها بن داود وإكسترا ودله الصحية ورعاية والعثيم والحمادي والحكير والتصنيع وسيج ولوبريف وتداول والسعودي للاستثمار)، فصار لها اسم وسعر من ملف الأسعار اللي نحدّثه كل ٥ دقائق، وتُكتب في «قائمة الأسهم» بالاسم أيضًا. رمز غيرها يبقى كما كان (رقم، والسعر لما يرد Yahoo).
- **قبل ما تحذف UrTV:** من شغّل «تخلّص من واجهة المصنع» ثم حذف UrTV بقي التلفزيون بلا شاشة رئيسية (شاشة سوداء). صار في الإعدادات صف «قبل ما تحذف التطبيق…» يقول هذا وفيه زر «رجّع واجهة المصنع»، ومكتوب في README. (إبقاء واجهة المصنع شغّالة وتعيين UrTV افتراضيًا فقط لم نغيّره في هذا الإصدار الخفيف.)
- **ملاحظات المختبرين:** عنوان «تحكم من الجوال» كان أعلاه على ٤٠ من ١٠٨٠، خارج الهامش الآمن ٥٪؛ صار الهامش (فوق وتحت). وسطر المصدر في صفحة المباريات ما يلمس العنوان (فراغ بينهما ويلتف لو ضاق).
- **الأذان والبطاقات بعد التحديث:** مستخدم اختفت أوقات الأذان وبطاقة الصلاة من الشاشة الرئيسية بعد 4.3.1. الشاشة الرئيسية كانت تقرأ المدينة والبطاقات من تطبيق الإعدادات، وإذا بدأت والتطبيق الثاني ما يرد (وقت التحديث، أو تلفزيون ما يشغّله من الخلفية) تبدأ بالإعدادات الافتراضية. الحين تحفظ آخر ردّ حقيقي على القرص وتستعمله، معلَّمًا قديمًا، لحد ما يرد التطبيق (وما يصير مكان الصلاة ولا يحرّك منبّه الأذان). لم نقدر نعيد المشكلة نفسها عند المستخدم، فهذا تحصين لأقرب سبب وجدناه.
- **الإذاعات والقرّاء:** أضفنا إذاعة «الشيخ عبدالله خياط» (بث مباشر من quran-uni.com، MP3 128، يمرّ على فحص الإذاعات عندنا). محمد أيوب (مرتل) موجود من قبل. أحمد طالب بن حميد (١٠٧ سور من ١١٤) لم نضفه بعد: صيغة القرّاء عندنا تفترض ١١٤ سورة متتابعة، ولازم نعرف أي السور ناقصة ونعلّمها «غير متوفرة» بدل أن تنقطع القراءة.
- **التثبيت بالأمر (Nokia Box 8000 وBeyondTV4):** رسالة «Unable to open file» (الملف ما وصل التلفزيون كاملًا) صار `install.sh` يرسله مرة ثانية ويثبّته مرة ثانية، وإذا فشل يقول بوضوح اترك مساحة في التخزين ثم أعد الأمر. رفض Play Protect (VERIFICATION_FAILURE) كان له إعادة ورسالة من قبل.
- **تقرير الإعداد:** التطبيقات اللي كان التلفزيون موقفها قبل الإعداد (Nokia وTCL BeyondTV) كانت تظهر في التقرير «أوقفها الإعداد»؛ صارت في سطر منفصل «كانت موقوفة قبل UrTV».
- **سمارت تيوب:** لو آخر إصدار ما فيه ملف لمعالج التلفزيون (مثل armeabi-v7a) يأخذ آخر إصدار كامل فيه واحد، بدل «ما فيه نسخة». والتثبيت بالأمر يتأكد أن حجم الملف على التلفزيون مثل حجمه عندك قبل ما يثبّته، ويرسله مرة ثانية لو نقص.

## 4.3.1

**بالعربي، باختصار:**
- **الأذان في وقته فقط:** إذا وصل منبّه الأذان متأخرًا (التلفزيون كان في السكون، أو الساعة قفزت عند التشغيل) ما يشتغل الأذان؛ بعض الناس كان يسمعه الساعة ١٢ الليل بلا سبب.
- **الشاشة الرئيسية ما ترجع سوداء ولا ضبابية:** عند الرجوع من تطبيق تظهر الصورة فورًا (نسخة صغيرة محفوظة منها) بدل الشاشة السوداء، والصورة الكاملة تظهر بعدها بسرعة؛ وما تعاد تحميل الصور إلا لو احتاج النظام الذاكرة فعلًا.
- **شريط «خلّ تلفزيونك يفتح على UrTV»:** صار سطرًا واحدًا ما يغطي أي بطاقة، وتوصله بالريموت (السهم لأعلى من الأزرار العلوية)، و«لاحقاً» يخفيه ٧ أيام ثم ٣٠ ثم نهائيًا.
- **المفضلة بعد إطفاء التلفزيون:** كانت تظهر خمسة تطبيقات فقط بعد التشغيل؛ الآن الصف يُبنى من جديد بعد ثوانٍ لين تظهر كلها.
- **نتيجة المباراة الصحيحة:** إذا كانت المباراة نفسها في أكثر من مصدر (فريقك، دوري، البطولات) تظهر مرة وحدة، بنسختها المنتهية ونتيجتها.
- **الإذاعة ما تستسلم:** إذا انقطعت المحطة أو تقطّع البث، نحاول نرجّعها وحدنا (بعد ثانيتين، ثم ٥ و١٠ و٢٠ ثانية، وبعدها كل نصف دقيقة) ونكتب لك السبب بكلام واضح: ما في إنترنت، أو المحطة ما تردّ، أو صيغة البث ما يدعمها التلفزيون. وإذا للمحطة مصدر ثانٍ نبدّل بينهم.
- **البطولات الكبرى:** مباريات دوري الأبطال والدوري الأوروبي ودوري الأمم وكأس العالم وكأس آسيا وكأس العرب والكؤوس المحلية الكبرى تظهر في صفحة المباريات وبطاقات الشاشة الرئيسية وشاشة التوقف، من مفتاح واحد «البطولات الكبرى» (يشتغل وحده في التثبيت الجديد). فريقك ودورياتك أولًا وبعدها البطولات، وبحد أقصى ٣ مباريات في البطاقة، وفي صفحة المباريات قسم واحد «مباريات اليوم وبكرة». وصارت «الدوريات كاملة» شاشة وحدة: بحث في الأعلى وأقسام (البطولات الكبرى، السعودية، أوروبا، آسيا وأفريقيا، العالم) كل صف بعلامة اختيار.
- **Open Shelf في تطبيقات مقترحة:** متجر لتطبيقات التلفزيون المفتوحة المصدر. تطبيق من طرف ثالث ما جرّبناه بأنفسنا، والتطبيقات اللي يثبّتها على مسؤوليتك.
- **«إعداد تلفزيوني» في الإعدادات:** صف تحت «الشاشة الرئيسية» يفتح الإعداد دائمًا، حتى لو UrTV هو الشاشة الرئيسية، عشان تشغّله من جديد أو تتراجع عن تغييراته.

**In English, in short:**
- **The adhan only at its own time:** an adhan alarm that arrives late (the TV was in standby, or the clock jumped at start) no longer sounds; some people heard it at midnight for no reason.
- **The home is no longer black or blurry on the way back:** coming back from an app shows the photo at once (a small copy of it is kept) instead of black, and the full photo follows quickly; the photos are let go only when the system really needs the memory.
- **The «Make your TV open on UrTV» bar:** one short line that never covers a card, reachable with the remote (UP from the top buttons), and «Later» hides it for 7 days, then 30, then for good.
- **Favourites after a power cycle:** the row showed only five apps after the TV was switched on; it is now built again a few seconds later until all appear.
- **The right match score:** a match that is in more than one source (your team, a league, the tournaments) shows once, as the finished copy with its score.
- **The radio keeps trying:** when a station drops or cuts, we bring it back by ourselves (after 2 seconds, then 5, 10 and 20, then every half minute) and say why in plain words: no internet, the station is not answering, or the TV does not support the stream's format. A station with a second source swaps between the two.
- **Big tournaments:** the Champions League, Europa League, Nations League, World Cup, Asian Cup, Arab Cup and the big domestic cups show in the matches page and in the home and screensaver cards, from one switch, «Big tournaments» (on by itself in a new install). Your teams and your leagues come first, then the tournaments, at most 3 games on a card, and the matches page has one section «Today and tomorrow». «Whole leagues» is now one screen: a search on top and sections (Big tournaments, Saudi Arabia, Europe, Asia and Africa, World), each row a tick.
- **Open Shelf in suggested apps:** a store of open-source TV apps. A third-party app we have not vetted ourselves; the apps it installs are at your own risk.
- **«Your TV setup» in the settings:** a row under «Home screen» that always opens the setup, even when UrTV is already the home, to run it again or to undo its changes.

## 4.3

**بالعربي، باختصار:**
- **«تلفزيونك»:** افتح التطبيق وتطلع لك أربع نوافذ بعلامات واضحة: الأسواق والمباريات والألعاب والإعدادات، وبضغطة وحدة تدخل أي منها.
- **ثماني ألعاب عائلية:** «الأسرع» يجاوب فيها الكل من جواله، وسبع بريموت واحد يدور بينكم: خمس خانات، الكلمة المفقودة، واحد مو معنا، بدون كلام، خلية الحروف، خمّن الكلمة، ودومينو. الأسرار لها شاشة تسليم تقول «غطّوا عيونكم».
- **شاهد المباراة:** من بطاقة المباراة في صفحة المباريات يفتح UrTV Player على المباراة مباشرة، مع دوريات أكثر.
- **UrTV النظيف:** زر وحد يخلّي UrTV نظيفًا فعلًا: الشاشة الرئيسية بالساعة والتاريخ وشريط التطبيقات، وشاشة التوقف بالصورة والساعة فقط، و«تلفزيونك» يفتح على الإعدادات. وتختار «بطاقة الصلاة»: سطر تحت التاريخ أو بطاقة فيها صلوات اليوم الخمس، وتحدد مكانها. الأذان والتذكيرات والقفل العائلي والتحديثات تشتغل كما ضبطتها، وكل شي يرجع بضغطة.
- **تخلّص من واجهة المصنع:** صف في الإعدادات تحت «اجعل UrTV الشاشة الرئيسية» يعطّل (ما يحذف) واجهة المصنع بتأكيدين وبضغطة ترجع. بعض التلفزيونات ما تعرض سؤال «السماح بتصحيح USB؟» لتطبيقنا؛ والشاشة تقول لك ذلك بوضوح وما تغيّر شي، وUrTV يشتغل ممتاز بدون هذه الخطوة.
- **شريط التطبيقات أسلس:** الحركة بين التطبيقات صارت أخف بكثير، خصوصًا على التلفزيونات الضعيفة.
- **تثبيت UrTV Player من داخل UrTV:** من «تطبيقات مقترحة» تثبّته وتحدّثه بضغطة.
- **توحيد المظهر:** الأزرار العلوية والبطاقات وشريط التطبيقات في الشاشة الرئيسية صارت بمادة وحدة في كل شكل، داكن أو فاتح (الإعدادات ← المظهر ← توحيد المظهر، مفعّل من الأصل؛ إذا وقّفته صار لكل واحد شفافيته وتعبئته).
- **صفحة الجوال بتصميم جديد:** بطاقة وحدة «على الشاشة» للرسالة و«ارسم» و«صوري»، والوضع الفاتح واللغة و«محفظتي» أزرار واضحة.
- **ألبوم صوري:** بطاقة لصورك من «صوري» تتبدل بتلاشٍ ناعم (كل ٤ ثوانٍ أو كل دقيقة) وتحتها تاريخ الصورة، على شاشة التوقف والشاشة الرئيسية. و«صوري» صارت تتسع لـ ٥٠ صورة، وتقدر ترسلها من جوالك (تُصغّر في الجوال وما يوصل معها مكان التصوير ولا وقته).
- **رسالة من الجوال:** اكتب سطرًا قصيرًا في صفحة الجوال ويظهر على الشاشة ٢٠ ثانية.
- **ارسم من الجوال:** من صفحة الجوال («ارسم» جنب الرسالة) ترسم بإصبعك ويظهر الرسم على شاشة التلفزيون وأنت ترسم، بستة ألوان، و«امسح» يمسحه من الجهتين، ويختفي وحده بعد ٨ ثوانٍ من آخر خط. نفس مفتاحي «رسائل الجوال» و«فوق التطبيقات»، وزر الرجوع يخفيه.
- **أذان للفجر من ملفك:** تسجيل ثانٍ لك يُؤذَّن به الفجر وحده.
- **المظهر والخلفيات:** شكل شاشة التوقف والشاشة الرئيسية وصورهما في صفحة واحدة؛ وللشاشة الرئيسية صور خاصة بها إن أردت، وتقدر تخفي أزرار الأسواق والمباريات والجوال ومركز التحكم.
- **دوريات جديدة:** دوري أبطال أوروبا، ودوري أبطال آسيا للنخبة، ودوري نجوم العراق.
- **المباريات:** المباراة المؤجلة أو الملغاة ما تظهر «مباشر» ولا قادمة (في بطاقة فريقك تُكتب «تأجلت» أو «أُلغيت»)، ونتيجة فريقك تظهر أول ما يكون في ملف الدوري.
- **كل الدوريات:** تحت قائمة «الدوريات كاملة» زر «كل الدوريات…»: الأشهر ثم كل بلد، وتتابع حتى ٨ دوريات.
- **تحديث UrTV Player من داخله:** إذا نزلت نسخة أحدث، يحدّث المشغّل بضغطة بدون حذف (قوائمك تبقى)، وخانته في «تطبيقات مقترحة» تقول «تحديث متوفر».
- **ساعة الشاشة الرئيسية في المغرب ومدن أخرى:** كانت متقدمة ساعة لأن بيانات المناطق الزمنية في التلفزيون قديمة؛ صارت الساعة والتاريخ ومواقيت الصلاة والتذكيرات تأخذ التوقيت الصحيح نفسه الذي تعرضه شاشة التوقف.
- **إذاعة القرآن والتلاوات المباشرة:** كل محطة تشتغل الآن بمشغّل أمتن؛ إذا انقطع البث يرجع وحده بهدوء، وإذا ما اشتغلت محطة القرآن السعودية يُجرَّب مصدرها الثاني، وما تظهر «صيغة البث غير مدعومة» لانقطاع عابر.
- **الإذاعات:** البث المباشر أثبت، وإذا علِق يرجع وحده بهدوء.
- **ذاكرة USB:** عارض الملفات في التلفزيون يبقى شغّالًا دائمًا.
- **تحديث تلفزيوني:** أمتن، وما يطلع تطبيق قديم قدّامك وقت تحديث الشاشة الرئيسية.
- **تطبيقات مقترحة:** في الإعدادات ← المزيد ← التطبيقات والمفضلة: SmartTube وTV Bro وVLC، لكل تطبيق سطر يقول ليش وزر تثبيت أو صفحته في المتجر (أندرويد يسألك قبل التثبيت). وفي الإعداد من التلفزيون تعلّم TV Bro وSmartTube (أو واحد منهما) لنثبّتها مرة وحدة.
- **البث المباشر من الحرمين:** قناة القرآن الكريم (مكة) وقناة السنة النبوية (المدينة) تفتح في يوتيوب أو SmartTube، وإذا ما فيه أيّهما تفتح صفحة منصة «الأولى» الرسمية في المتصفح (ما نشغّل البث داخل تطبيقنا: المنصة ما تعطي رابطاً ثابتاً له).
- **أُزيل** الحساب الجعفري من طرق حساب الصلاة (من كان عليه يرجع لحساب بلده).

**In English, in short:**
- **«تلفزيونك» (Your TV):** open the app and four windows with clear marks appear: Markets, Matches, Games and Settings; one press goes into any of them.
- **Eight family games:** «The Fastest» (everyone answers on their phone), and seven with one remote passed around: Five Boxes, Missing Word, Odd One Out, Without Words, Letter Hive, Word Guess and Dominoes. Secrets get a hand-over screen that says «cover your eyes».
- **Watch the match:** from a match's card on the Matches page, UrTV Player opens straight on the game; more leagues are covered too.
- **Clean UrTV:** one switch makes UrTV really clean: the home with the clock, the date and the apps bar; the screensaver with the photo and the clock only; «تلفزيونك» opens on the settings. Choose a «Prayer card»: a line under the date or one card with today's five prayers, and where it sits. The adhan, reminders, the family lock and updates keep working as you set them, and one press brings everything back.
- **Get rid of the factory interface:** a row in the settings under «Make UrTV your home screen» turns the factory interface off (never deletes it), with two confirmations and one press to undo. Some TVs do not show the «Allow USB debugging?» question to our app; then the screen says so plainly and changes nothing, and UrTV works fine without this step.
- **A smoother apps bar:** moving between apps is much lighter, especially on weak TVs.
- **Install UrTV Player from inside UrTV:** from «Suggested apps» you install it and update it in one press.
- **One material on the home («توحيد المظهر»):** the upper buttons, the cards and the apps bar share one fill, line, corner, accent and focus in every look, dark or light (Settings › Look › «توحيد المظهر», on by default; off, each has its own strength and fill; `optimize/saver.sh looksync on|off`, `surface quick|cards|tray 30..100 look|glass|graphite`). The apps bar's corners are 24 px (they were 32) and its focus ring follows the look and the accent.
- **A redesigned phone page:** one card «على الشاشة» for the message, «ارسم» and «صوري»; light/dark, the language and «محفظتي» are real buttons; no pill shapes.
- **My photo album:** a card of the photos in «صوري», crossfading every 4 s or one a minute, with the day each was added, on the screensaver and the home screen. «صوري» holds up to 50 photos, and you can send them from your phone (made smaller there, without where or when they were taken).
- **A message from the phone:** type a short line on the phone page; the TV shows it for 20 s.
- **Draw from the phone:** on the phone page («Draw» beside the message) you draw with a finger and the drawing shows on the TV as you draw, in six colours; «Clear» clears both sides, and it fades by itself 8 s after the last line. The same «Phone messages» and «Over apps» switches; Back hides it.
- **A Fajr adhan of your own:** a second recording, for Fajr only.
- **Look and wallpapers:** the screensaver's and the home's look and photos on one page; the home can have photos of its own, and the markets, matches, phone and Control Center buttons can be hidden.
- **New leagues:** the UEFA Champions League, the AFC Champions League Elite and the Iraq Stars League.
- **Matches:** a postponed or cancelled game is no longer shown as live or upcoming (your team's card says «Postponed» or «Called off»), and your team's result shows as soon as its league's file has it.
- **All leagues:** under «Whole leagues», «All leagues…»: the best known, then every country; follow up to 8.
- **UrTV Player updates from inside it:** when a newer one is published, the Player updates in one press, never uninstalled (your lists stay); its tile in «Suggested apps» says «Update available».
- **The home's clock in Morocco and a few other places:** it was an hour ahead because the TV's own time-zone data was old; the clock, dates, prayer times and reminders now use the same offset the screensaver shows.
- **Quran Radio and the live recitations:** every station now plays through the sturdier player; a dropped stream comes back by itself, the Saudi Quran Radio tries its second source, and a passing drop no longer says «Stream format not supported».
- **Radio:** live stations hold up better and restart quietly when they stall.
- **USB sticks:** the TV's own file viewer is always kept on.
- **«تحديث تلفزيوني»:** sturdier, and the app you used before no longer comes to the front while the home screen updates itself.
- **Suggested apps:** Settings ← More ← Apps and favourites: SmartTube, TV Bro and VLC, each with one line on why and an install button or its store page (Android asks before it installs). The in-app setup has a tick for TV Bro and one for SmartTube.
- **Live from the two Holy Mosques:** the Quran channel (Makkah) and the Sunnah channel (Madinah) open in YouTube or SmartTube, and with neither on the TV, the official Aloula page opens in the browser (nothing is streamed inside our app: the platform gives no fixed address for it).
- **Removed:** the Ja'fari prayer calculation (a saved choice becomes the country's own).

## 4.2

- **(A later 4.2 build) The in-app setup «جهّز كل شي» goes on after its restart** (a user report on 4.2: it stopped at «قياس الذاكرة قبل» and the TV restarted). The «resume after restart» mark is now saved before the restart (the app is closed with the TV, so the old order never wrote it); the restart is announced first; each memory reading has a time limit and a failed reading is skipped with «تعذّر القياس، كمّلنا.» instead of stopping the setup. tests/setup_runner_test.py R31, R32.

- **Chromecast with Google TV: casting and the Google Home remote kept** (a user report on 4.1: «جهاز غير موثوق فيه — تعذّر التحقق من الجلسة… برامج ثابتة قديمة» until the Google TV home came back). The cast receiver reads its device credentials from the setup wizard (setupwraith), which the home switch used to turn off. Where the wizard holds them (`castinfo.CastInfoProvider` AND a Google-made device: the maker Google, or the codename sabrina, boreal or kirkwood; a TCL G07's wizard has the provider too, so the provider alone was not enough) it now stays on, in `install.sh` and in the in-app setup, and our home is still asked to be Home; if the wizard keeps Home there, `optimize/dock.sh cast off` puts our home first (casting lost) and `cast on` brings casting back (optimize/cast.sh). docs/TVS.md corrected. Tests: tests/cast_test.py, tests/install_retry_test.py, tests/setup_engine_test.py.
- **A weak TV does less** (a user report on 4.1: heavy lag after the update from 4.0). `Ram.low`: Android's low-RAM flag, or under 2.5 GB in all. There the remote's keys outside the home are not filtered (the Settings key outside the home is the TV's own again), the home lets its photos and its card page go while another app is in front (onTrimMemory), the markets open in «عادي» and «مباشر» asks at most every 60 s, and the page gets `#lowram=1` (no seconds, markets every 15 minutes, the adhan check every 15 s, no transitions). On every TV: the clock's minute tick reads the screensaver's settings off the UI thread and a Wi-Fi broadcast redraws only when the minute moved; the screensaver's city lookup is a map (3,679 cities were scanned at each read), and a city saved before 4.1 gets its country found once and kept. tests/lowram_test.py.
- **The home app targets Android 14 (API 34)**, as the screensaver already did: Play Protect blocked it as «built for an older version of Android» when installed from Downloader. What the new target asks for: the setup's foreground service names its type (specialUse, FOREGROUND_SERVICE_SPECIAL_USE); USE_EXACT_ALARM keeps the adhan and the reminders exact on a new install (Android 14 no longer gives SCHEDULE_EXACT_ALARM to a 33+ target; the inexact fallback stays); a foreground start Android refuses from the background is caught (MusicService) instead of crashing; the notifications permission (Android 13+) is asked once, when the player first opens, with one line («اسمح بالإشعارات…»), no longer at each open of «تلاوة». minSdk unchanged. tests/target_sdk_test.py.
- **«المهام» with a time** (docs/PROPOSALS-NOV2.md §4): a task may have a due time, «قبلها بـ» 0, 10, 30 or 60 minutes, a repeat (daily, weekly), an optional soft chime (off by default) and where it shows. At the time a silent white card shows over the screensaver (the page) and the home (ReminderCard), dismissed with OK: «تم» or «ذكّرني بعد ١٠ دقائق»; over another app a 5-second notice; it waits for the adhan. The alarm is the adhan's kind (ReminderScheduler/ReminderReceiver) and comes back after a reboot. Set on the TV («ذكّرني» beside a task), on the phone page (a date and a time beside the text box) and `saver.sh tasks add '<text>' --at '2026-11-05 17:00' --before 30`. Tests: tests/reminders_test.py, tests/reminder_page.test.mjs.
- **The football home** (docs/PROPOSALS-NOV2.md §1; a choice, not the default): Settings ← «المظهر» ← «الواجهة» ← «كرة القدم»
  (`saver.sh homelayout football`; `classic` is the home as it always was). Over the photo, under the clock, three glass cards: «الطقس»
  (city, temperature, feels-like, humidity, wind), «أوقات الصلاة» (the next one lit, its time left) and «مباريات اليوم» (the followed teams
  first, then the followed leagues, the Saudi Pro League when none is followed; a game that meets a prayer says which in amber). The
  favourites bar is the same as everywhere; while the focus is on the games they open into a row of cards (◀ ▶) and the tray moves 40 px
  down (`lowerTray`), back before a tile lifts. The page draws the cards (#football=1, HomeCard's WebView); FootballFocus puts a focus
  target over each. **«المباريات»** (MatchesActivity, #matchpage=1): OK on a game, or Settings ← المزيد ← المباريات والأسواق ← «مباريات
  اليوم». The days (yesterday to five ahead), the leagues with «فرقك» first and their counts, the live minute and score, the prayer clash
  notes; OK on a game opens its card: the round, the venue (league_fixtures.py now keeps `strVenue`), the channel, «مع الصلاة» (the
  prayers around it on a line, one sentence), «ذكّرني قبلها بنصف ساعة» (a task with a reminder at kick-off, «قبلها بـ» 30, silent) and «تابع». **Broadcast
  marks:** assets/shared/broadcast.json, a plain text mark per league shown only for a high-confidence, whole, verified row in season;
  .github/tools/broadcast_check.py (run by tests/check.py) fails a row with no source or seasons, or past its last season. No row yet: none
  of the proposal's sources could be opened from here. tests/football_test.py, tests/football_page.test.mjs; the page's budget is 740 KB.
- **«الأسواق», a page of its own** (docs/PROPOSALS-NOV2.md §6, MarketsActivity): OK on the home's stocks card (now a button, like «المهام»)
  or Settings ← المزيد ← المباريات والأسواق ← «صفحة الأسواق». «السوق»: TASI and its day against yesterday's close, «اتجاه السوق» over the 30
  companies we fetch, the top 3 up and down (and «الأكثر نشاطًا» once CI's file carries the volume); «قائمتي»: the stock list with each day's
  line, gold, silver, Brent and the riyal's fixed pegs; «اليوم / أسبوع / شهر / سنة» on TASI and each stock card, from a year of daily closes CI
  asks once a day (its own daily.json, downloaded only by a TV that opens the page, once a day; the 15-minute file stays about 20 kB); a stock's card with the open, the day's range, «أضف إلى قائمتي» and «أظهره في شريط
  الأسواق». Only data we have: no sectors, whole-market figures, dividends or news (the «الأخبار» tab is built but off until a source agrees).
  CI keeps the volume and the 52-week range from the same Yahoo answer. **«محفظتي»** (§7): holdings with their buys, totals, allocation,
  «أخفِ المبالغ», «اقفل محفظتي» with the parental PIN; added on the TV's number pad or from the phone's own page (/m, «أسهل من الجوال»). Kept
  in the home app's private prefs only: never in a URL, ConfigProvider, a report, a settings export (refused) or a command; the phone gets
  them only while paired and while the TV is editing them; `pin reset` wipes them.
- Three owners' options, each off by default (nothing changes until chosen): «الآية والحديث» (`saver.sh versekind both|verse|hadith`: the verse card with verses only or hadith only), «إظهار الثواني» (`saver.sh seconds on|off`: the seconds on the screensaver's clock, small, in fixed-width boxes so nothing moves each second, in every clock size) and «الخروج من تلفزيونك» (`saver.sh backexit press|hold|three`: where the TV keeps its own home, our home leaves only on a long Back or three Backs, with a short hint the first time a Back is ignored). tests/user_options_test.py and page tests.
- **The favourites bar** (docs/PROPOSALS-NOV2.md §1, FavBar.java): one glass tray, the same on every look and layout, x 120 to 1800 and
  218 high, 54 px above the screen's bottom; five 304×170 tiles 24 apart, the first on the right, more scroll inside the tray and never
  leave it. The focused tile lifts 6 px and grows 1.08 in 150 ms with a 3 px green ring (DGA green on light, #8FE0B4 over a photo); the
  app's name sits centred over it and hides when the focus leaves the bar. The only move is 40 px down for a widget that opens into a
  scrolling row (`lowerTray`, for the football home's matches; nothing calls it yet). «أكمل المشاهدة» is its own row below the first
  screen (the owner's choice): ▼ from the tray slides the home up to it, ▲ slides it back; the tray stays at y 808 either way. **«رملي» on the home itself:** with that look the
  home's own veil, words and labels are sand, ink and flag green in the light and green for gold in the dark (Look.SAND_LIGHT/SAND_DARK,
  checked for contrast like the other two).
- **The UX review, done** (docs/UX-REVIEW.md on work/ux-review; work/ux-impl). **The app's options:** a long OK on the app, or the remote's
  Menu key on it, shows a small box right above the app, its width, no title (a quiet «اضغط مطوّلاً للخيارات» beside a favourite's name
  the first six times): «انقل», «أخفِ», «اقفل», then ★ (in or out of the favourites) and ⓘ (Android's app details, where its uninstall is). The old
  long-press menu's other items have their visible places (the update, «تلاوة وأذان» and the adhan in the settings, the default favourites
  in «ترتيب المفضلة»), and everything in the box is also in Settings ← المزيد ← التطبيقات والمفضلة (new rows «قفل التطبيقات» and
  «تفاصيل التطبيقات»), so nothing is long-press-only. **«مركز التحكم»:** Wi-Fi and Bluetooth first, side by side; no tile asks for a long OK any more (the screensaver's
  line says «ابدأها الآن»; the sleep service is turned on from «مؤقت النوم», as its notice now says). **«الرقابة الأبوية»:** a button in
  Settings ← المزيد, and its page starts with a card and two buttons («فعّل الرقابة الأبوية» / «ما الذي يُقفل؟», then «التطبيقات المقفلة» /
  «غيّر الرمز»). The DNS filter is «تصفية المواقع» (was «حماية العائلة», a name too close to the lock). **A fifth look, «رملي»** (`sand`):
  white cards on sand, hairlines, and a calm focus: a soft green fill with a DGA green line round it (GlassStyle.Look.ring) in every screen
  and on the home's top buttons (rounded rectangles in this look). The default look is unchanged (glass); every look keeps its colours.
- **«المصادر» on CultraView and other non-TCL TVs** (work/user-fixes): the live TV app and the source picker are no longer TCL's only. The
  home app finds them on the TV each time the menu opens (TvVendor: the configured TCL ones first, then CultraView's `com.cultraview.livetv`
  and `com.cultraview.setting/.SourceActivity`, MediaTek's tvcenter (Xiaomi, Hisense, Haier), MStar's (Skyworth), Sony, Philips, Google Live
  Channels). An HDMI input tries the standard passthrough link, then each live TV app the TV has, then the picker, then the TV's settings.
- **The recitation and the adhan at a normal level**: the recordings are quiet next to TV sound, and the player played them at unity gain.
  It now lifts them by +6 dB inside its own audio session (LoudnessEnhancer: a gain with a limiter, so no clipping). The TV's volume, its
  mute and the adhan's own level (never above the person's choice) are not touched; a TV without the effect plays as before.
- **US stocks' change as an amount** («تغيّر الأسهم الأمريكية», `optimize/saver.sh stkchg amount`): the stocks card shows a US stock's
  change as an amount (▲ 2.25) instead of a percentage; the default stays the percentage, Saudi codes always keep it, and the page's
  link only gets `&stkchg=amount` when it is chosen.
- **optimize/measure.sh with a run folder whose path has spaces** (macOS «Application Support»): every `$RUN` path is quoted
  (tests/measure_space_test.py runs it with such a folder).
- **LG and Samsung (BETA): «تعديل الفجر» … «تعديل العشاء»**: each prayer moved by whole minutes (−20 to +20) in the TV's settings screen,
  as in the Android app; the page's times, countdown and adhan move with it. The list scrolls to keep the chosen row in sight.
- **Arabic letters joined everywhere**: the last letter-spacing on Arabic text is gone (the adhan bar, the «يوم» unit, the score, the
  phone code's Arabic placeholder, «يُتلى الآن» in the player); only Latin or digit-only text keeps it (tests/arabic_spacing_test.py).
- **The home's cards on the newest page**: the launcher always opened the page of its own build, while the screensaver downloads the
  newest one, so page fixes (the markets' requests among them) never reached the home and its stocks card stayed stale. The screensaver
  now shares its downloaded page (ConfigProvider .../page/, read-only, only when newer than its own and with its automatic update on) and
  the home opens a copy of it when its build stamp is newer than the launcher's own page; otherwise its own page as before.
- **«قائمة الأسهم» takes a company's name too**: a Tadawul code (2222, also ٢٢٢٢ in Arabic digits, which was refused before), a name
  (أرامكو, مصرف الراجحي, بنك الرياض, Aramco) or a US ticker; a name is turned into its code and a short message says what it was taken as
  («الأسهم: أرامكو 2222»), and the row shows the company beside each code.

- **The new settings screen** (work/settings-v2, the owner's choices in notes/settings-proto): big buttons, «الأذان» wide on top with its state
  under it; OK opens the home's adhan page on its switch (now its first row), so OK, OK turns it on or off, behind the family lock as before.
  Then «الموقع والصلاة», «الساعة والأرقام» (new: 12/24 hours, digits, month names together), «تلاوة وأذان», «البطاقات» («شاشة التوقف» and
  «الشاشة الرئيسية»), «المظهر», «مركز التحكم» (the home's panel, behind its pill's lock), «التحكم من الجوال», «تحديث تلفزيوني» (the apps'
  and the page's updates together), «أرسل تقرير» (new: the home's QR code to docs/share with the versions, Android and WebView only) and
  «المزيد» (matches and markets, apps and favourites, new shows, «حماية العائلة»). Every row is still there (SettingsHub.ROWS); the
  commands are unchanged. On/off rows have no switch any more (choice I): three DGA-green triangles at the row's start and the state word
  in green while on, in both apps' settings, the adhan page, the family lock and the phone page (whose iOS-style pill is gone, and the page
  is 113 bytes smaller). The home answers the screensaver's new read-only .../adhan_on.

- **Version 4.2** on `next`: the `VERSION` file says 4.2, so test builds from `next` show «4.2» (the apps' `versionName`; the build is still the run number and `version.txt` is still `3.<build>`).

- **«إعداد تلفزيوني»: the whole setup from the TV alone, one button «جهّز كل شي»** (work/phone-setup). Only the home app is installed (one Downloader code, 9378345); the run downloads the screensaver from `apk-latest`, installs it only when it is signed with the home app's own key, and does what `optimize/run.sh` does in its order: backup, keep, the measurement before and after (with restarts, resumed by itself), grants, the safe list, the community list (offline: left), the tweaks, the screensaver, TV Bro and SmartTube (on, one box to skip them), TCL's auto-start with ASSOC_START and `appops write-settings`, the home switch, the report as a QR code for `docs/share`. Nothing is changed before the plan with this TV's real counts is shown and «ابدأ» is pressed. The home switch follows `install.sh`: the Wi-Fi question once when the setup wizard owns the network, then the safe order (wizard off, Wi-Fi read, our home in front, only then the stock home off), the wizard put back on any failure, the journal's `step` before each step. While a run goes our screensaver steps aside and the screen is held on; a prompt with no answer in 20 s gets «ما ظهرت الرسالة؟ أعد تشغيل التلفزيون…». The old five-step «ابدأ» is gone (one way). The QR encoder now also makes level-L codes up to version 40. `docs/PHONE-SETUP.md` says what it cannot do.
- «إعداد تلفزيوني»: while a run waits for the TV's «السماح بتصحيح USB؟», our screensaver stays away (a prompt sent under it stays stuck until a restart, the tester's diagnosis; TCL ignores the screen's keep-on flag, since the prompt's window, not ours, is in front then). Two ways, both inside the app: a screen wake lock the app holds itself for the wait (WAKE_LOCK, already declared; Android starts no screensaver while one is held, and does not look at which window is in front), and a flag the screensaver asks the launcher for when it starts (`content://sa.taweeqo.home.nowplaying/setup_hold`, signature permission): while it is set the dream ends at once. Poking the TV's user activity needs DEVICE_POWER, which a normal app cannot hold. The hold ends when the answer comes or the wait gives up, and by itself after 240 s in any case; with «جهّز كل شي» it is taken around the runner's connection (`SetupHost.open`), beside the run's own hold (`.../setup`, the whole run). Log tags `UrTVSetup` and `UrTVSaver`.
- «مركز التحكم»: a tile «البلوتوث» («الريموت والملحقات») opens the TV's remotes-and-accessories screen: `android.settings.BLUETOOTH_SETTINGS`, else Android TV's accessories action `com.google.android.intent.action.CONNECT_INPUT`, the first that resolves (both in the manifest's `<queries>`); no tile when neither does. Locked by `@tvsettings`. It sits after «انعكاس الشاشة»; with ten tiles the panel stays inside the screen on 1080p, 720p and 540p (four to a row, or two rows of five on a small screen).
- «الرجوع يفتح شاشة التوقف», off by default: Back on our home (nothing to go back to) starts the screensaver's preview, as Clean Your TV does (c63d36a1), the way the «شاشة التوقف» pill starts it and behind its lock (`@saver`). Only as the TV's home and at the top (Back in the grid still goes to the dock first; a home opened from the «تلفزيونك» tile still leaves). `optimize/dock.sh backsaver on|off`, and on the TV: الإعدادات ← الشاشة الرئيسية ← «الرجوع يفتح شاشة التوقف» (مفعّل/متوقف, beside «زر المهام»). The row lives in the screensaver's settings (`#backsaver=1` while on) and the home moves its own switch, the one `dock.sh` sets, when the row changes (`Dock.followBackSaver`, at the next tick or return); `dock.sh backsaver` sends both, so the row says what Back does.
- The remote's Settings key on our home (a user's request): a short press opens the TV's own settings (behind `@tvsettings`), a long press (held 500 ms) opens ours (behind `@urtv`, the TV's own if the screensaver app is missing). The key now waits for its release, or for a repeat that late, before it acts; a remote that sends no repeats is judged by how long it was held. Outside our home it is unchanged (`SettingsKey`: the TV's settings).
- No trailing «…» on menu items: the app menu's «تحديث تلفزيوني», «تلاوة وأذان», «إعدادات الأذان», «الرقابة الأبوية», «كل المصادر» in the inputs list, and in the screensaver's settings lists «بحث عن مدينة أو قرية», «تصفح الدوريات», «بحث عن أي فريق أو منتخب» (only the dots there). A text that is still working («جارٍ التحقق…») keeps them.
- The app's long-press menu on our home (a user's request): under its last item a row of two small buttons, «تفاصيل التطبيق» (Android's app-details screen for that app) and «حذف التطبيق» (Android's own uninstall, which asks to confirm; not shown for a system app or our two apps). None in kids mode; both behind the family lock (`MENU_APP`: «قفل الإعدادات», the TV's settings' lock and the app's own). No «إيقاف إجباري»: a normal app cannot force-stop another, and the TV's details screen cannot be opened on its «فرض الإيقاف», so it would only have been the same screen again. The launcher now declares `REQUEST_DELETE_PACKAGES` (a normal permission; without it Android 9+ drops the uninstall request).
- Stability and speed from Clean Your TV (MIT, up to 3cd274f8): the community lists re-taken (416 TVs, 164 new); an **input guard** before anything is turned off (`optimize/disable.sh` and the setup on the TV): the TV's inputs, tuner and keyboards by name (`optimize/lists/inputs.txt`, refused like core.txt) and by the TV's own answer (`dumpsys package`: TV_INPUT_HARDWARE asked for, a TvInputService or an input method served), left on, and nothing turned off when that answer cannot be read; `com.tcl.xian.StartandroidService` is kept now (TCL's firmware updater needs it: it moves from the safe list to `keep.txt`, so a TV an older run set gets it back on), as is Xiaomi's `tvsetup.partnercustomizer` (the remote's app keys and pairing); `com.tcl.partnercustomizer` stays on the safe list (our home answers the app keys); first-run wizards (`oobe`) are never taken from a community list; TCL's Guard key (4140) does nothing on our home (TCL's cleaner would kill the adhan); and the tweaks compile our two apps ahead of time from their profile (`cmd package compile -m speed-profile`, Android 7 and newer, journaled, undone with `--reset`).

Four options for the adhan, each a switch in «تلاوة وأذان» ← الأذان and each off until it is turned on. The adhan itself stays off by default.
- «الأذان على شاشة التوقف فقط» (#49): the adhan plays only over the screensaver or our home screen; another app or an input in front gets none. `optimize/music.sh adhan saver-only on|off`.
- «تنبيه عند الأذان»: a calm text notice for 5 seconds at the prayer's time, «حان وقت صلاة العصر», over whatever is in front, even when the adhan is off or skipped. A system toast (no permission). `optimize/music.sh adhan notice on|off`; the status says what the last alarm did (`adhan_alarm_last=`).
- «تكبير فقط»: a third length next to «أذان مختصر». Only the opening takbir plays (cut at 14 seconds, a 2-second fade), the same time for every recording. `optimize/music.sh adhan takbir on|off`.
- «شاشة التوقف وقت الأذان»: at the prayer's time the screensaver starts so the clock and prayer screen show, only when our home is in front, never over another app. `optimize/music.sh adhan saver-at on|off`.

- «المهام» (issue #48): a text field with «إضافة» inside the screen, so a task can be added on a Google TV where the system's speech window gives nothing (its search box never reaches our app). The field takes the TV keyboard's own mic (Gboard, Leanback), its action key is «إضافة» (not search) and Enter adds; the D-pad reaches it with the usual gold focus. It is the same add as `optimize/saver.sh tasks add` (up to 12 tasks, 60 characters), Arabic and right to left.
- «🎤 تكلّم» is shown only when the TV has a speech recognizer (`SpeechRecognizer.isRecognitionAvailable` or an activity for the speech intent; the manifest now lets Android 11 show us recognizer services); a speech window that opens and closes at once with nothing hides the button for that visit. No dead button.

- **Home switch when the setup wizard owns the Wi-Fi** (TCL G08/G10/G14 on Android 12–14, Google TV sets such as a G7max: the most common reason the home switch was skipped). `optimize/install.sh launcher` no longer just goes on with the wizard kept and ends in «Home switch skipped»: before anything is changed it pauses once (exit 5, `run.sh: paused at launcher`) with an Arabic line for the person: forget the Wi-Fi network in the TV's Settings ← الشبكة and join it again with the same password, then say «كمّل». The next run reads the network's owner again. If it moved off the wizard (seen on a TCL G08, Android 14: it moves to the Settings app at once), the switch goes in the safe order: the wizard off first while the stock home is still Home, the Wi-Fi checked read-only (still connected, no saved network fewer), our home started and confirmed in front, and only then the stock home off and the HOME role ours (the order from CleanYourTV, MIT). A Wi-Fi that changed, or our home not coming up, puts the wizard and the stock home back at once. If the network did not move, it is as before (the wizard stays on; if Home stays with the stock home, one plain line and the «تلفزيونك» tile). It never asks twice, and never forgets, deletes or changes a network itself. The journal (`home-switch.json`) now names each step before it acts.
- The `!! The safety switch put the stock home back` line is printed only when it is true (Home answers with the stock home, it is enabled, and the journal says restored). Otherwise the line says what the TV shows: the stock home back, the stock home still OFF (with `optimize/restore-home.sh`), Home already ours, or that the TV did not say. On 4.1 the old fixed line was printed while `launcherx` stayed disabled.

- Remote: TCL's own keys work on our home: Netflix (4062), YouTube (4065) and Prime Video (4099) open their app when it is installed, and are passed on otherwise; the Settings key of a TCL G05 (4077) is the Settings key like 176 and 83 (they were logged by `UrTVKeys` and dropped).
- Setup on Android 9 and 10 (SDK below 30): `optimize/tweaks.sh` no longer sets the Play Store's standby bucket (6 of 7 Android 9 reports still ended "with problems" because the TV kept `active`). It is skipped with one journal line (`skipped_standby_bucket`), no `!!`. Undo still puts back a bucket an older run recorded.
- Setup no longer turns the cached-apps freezer on (`cached_apps_freezer`): one report linked it to apps hanging after standby, and Android 14 has it on by itself. The Play Store background tweak stays. A TV an older run already set gets its own value back from `optimize/tweaks.sh restore`, from the next apply, and from `reset.sh`.
- Screensaver: the Arabic line under the clock («بتوقيت الرياض») and the card labels («الصلاة القادمة», «المباريات») no longer have letter-spacing: Chromium breaks the joining of Arabic letters when it is not 0, so the letters were cut apart on some TVs.
- Never disabled: `com.android.sdksandbox` is now in the core list (`optimize/lists/core.txt`), beside `com.android.location.fused` (already there; a Clean Your TV report of a boot loop on a TCL). The app's copy of the lists (`SetupLists.java`) is regenerated.

- «تبديل الآية والحديث»: the verse-or-hadith card can change every 3 minutes instead of once a day (a verse, then a hadith, titled «آية كريمة» / «حديث شريف»), on the screensaver and the home screen's cards. The default stays one a day; the row shows in «بجانب الساعة» while the verse card is chosen. `optimize/saver.sh verse 3|day`.
- «تبديل الصورة كل»: 1 minute is a new choice everywhere, and 30 seconds on a TV with 2 GB of memory (MemTotal 1600 MB or more, read once with `ActivityManager.getMemoryInfo`: the app had no memory read before). A smaller TV does not offer 30 seconds, `optimize/saver.sh photos 30s` is refused there with the MB it has, and a 30-second value that reaches it is used as 1 minute. The page gets `#photos=0.5` and checks the photo every 5 s only then; the default stays 30 minutes.
- Three parts that can now be hidden, each shown as today until it is turned off: «المناسبة القادمة» at the bottom middle of the screensaver (the days to Ramadan and the feasts, iftar and suhoor in Ramadan; its place stays empty so nothing else moves; `optimize/saver.sh occasion off`), «تعتيم الليل» (the screensaver no longer darkens from 21:00; `optimize/saver.sh nightdim off`), and the «المهام» button on the home screen (taken out of the row like the «تلاوة وأذان» button; the tasks stay in the «المهام» card and on the phone; `optimize/saver.sh taskspill off`). Rows in the settings: «العرض» ← «المناسبة القادمة» and «تعتيم الليل», «الشاشة الرئيسية» ← «زر المهام».
- «تحديث الشاشة الآن» is now «تحديث صفحة شاشة التوقف», and its line says it updates the screensaver's page only and points to «تحديث تلفزيوني» (same category) for the two apps, which now says «تحديث التطبيقين»; people took one for the other (rows 421, 441). The same update runs; the version lines stay under it.
- «تلاوة وأذان» ← الإذاعات: a row «البث المباشر من الحرم» that opens the broadcaster's own live page or channel (SBA's Quran channel) in its own app or the browser; no stream in our app. Its link (`HaramLive.URL`, https on sba.sa, aloula.sa or youtube.com only) is **empty** for now: the official link could not be opened and confirmed from the build machine, so the row does not show until it is filled in.

## 4.1

The fixes for what broke after updating to 4.0: on TCL the phone remote stopped working inside other apps and the adhan was not rescheduled after an update (TCL's ASSOC_START op: `optimize/autostart.sh` now allows it; TVs already set up get it from the agent with «حدّث تلفزيوني»); a muted TV stayed at volume 0 after the adhan; the Settings key did nothing on HDMI; the screensaver cut phone pairing. Also in it: the new phone page, «نظام الساعة» 12/24, «حفظ» in long lists, «انعكاس الشاشة», and 3,679 cities in 242 countries and territories.

## 4.0

**Version 4.0:** the release has a name now, the `VERSION` file at the root («4.0»). The apps' `versionName` is exactly `4.0` (what Android's app info shows), the `versionCode` is still the GitHub run number, so every build installs over the last; the screens show «4.0» (the build only in the reports)
(settings «الإصدار», «تحديث تلفزيوني», the phone page, `saver.sh show`). Updates are untouched: `version.txt` is still exactly `3.<build>` (an app installed
before 4.0 (build 142 and later) reads it as before and still sees the update), and the apps compare by build, never by name. Master builds publish `apk-latest` as before and a
numbered release tagged `v4.0.<build>` (only the URL shows it; the title is «UrTV 4.0», the build is in the body); the older `v3.N` ones stay.

**Phone**
- The phone remote's arrows, OK, Back and Home work in every app, through our accessibility service («تلفزيونك: التحكم والكتابة من الجوال», renamed from «…: الكتابة من الجوال»; or the sleep timer's service from Android 13): the dpad global actions on Android 13+, a focus move on the window in front before it (OK = a click on the focused node). Our own screens keep their exact key path; the phone page names the service when it is off. A phone key stops a playing adhan first when «إيقاف الأذان بأي زر» is on. Log tag `UrTVRemote`: the key, the route and the answer only.
- Typing from the phone into other apps: the typing service now declares `typeWindowStateChanged` (read by nobody) so Android tracks the window in front and the field can be found; it also takes the input-focused field first and fields that accept set-text. A fixed-words log (tag `UrTVType`) shows each step.
- «تحكم من الجوال» is the first row of «الجوال والتحديث», and that tile names it.
**Remote**
- The remote's Settings key outside our home (a receiver on HDMI, Live TV, any app) opens the TV's settings, so the picture mode can be changed per input with the stock launcher still off. Through our accessibility service «تلفزيونك: التحكم والكتابة من الجوال»: it asks Android for keys only while our home is not in front and no stock home is enabled, passes every other key on untouched and unlogged; a service that is on needs nothing after the update. On our home the key still opens our settings. «وضع الرسيفر» (the stock launcher kept on) is a design in docs/TVS.md, not built: on a TCL the stock launcher takes Home back.
**Fixes from the TV test**
- After the app updates itself (157 → 159, 159 → 160 on the owner's TCL) Android left our accessibility services unbound and the switch at 0 until a reboot. The home now heals it after an update, at boot and when it first shows (with WRITE_SECURE_SETTINGS: the switch to 1 and the same list written again; other apps' entries untouched, a lost one only logged under `UrTVA11y`), `dock.sh type-setup` does the same when the TV says ours is not bound, and the phone page says «التحكم في التطبيقات الثانية متوقف: …» instead of doing nothing.
- An adhan on a muted TV no longer leaves it at volume 0: the level is put back and the TV muted again.
- The screensaver coming over the pairing screen no longer switches phone control off (only leaving the screen does); «ابدأ» in «إعداد تلفزيوني» has the focus once the screen is drawn.
- Phone page: Arabic counting («8 ساعات و 56 دقيقة», «دقيقتين»), the TV's real screensaver delay (45 s) shown as the current choice, «بدون» saved by the first press again, one swipe = one step, the text field no longer under the tab bar.
- A tile «تلفزيونك» (an activity-alias with LEANBACK_LAUNCHER and our banner) opens the home from the TV's own apps row, for the one setup in four that keeps the stock home (setupwraith / launcherx); it never changes which home is the default, Back at the top of our home then leaves it for the home that opened it, and our own «كل التطبيقات» does not list it.
- The adhan alarm no longer falls back to the bundled place (Riyadh) when the screensaver's settings cannot be read (the owner's TCL kills its process and refuses to start it from the background): the last good place is kept, a failed read never reschedules, and the alarm is set from the place it was judged by (log tag `UrTVAdhan`); the home's other settings keep their last good values meanwhile.
- Phone page, «الإعدادات»: the cards being chosen are no longer put back by a TV answer that was still on its way (a «بدون» pressed soon after a save sent the old card again); the message over the page no longer takes taps.
- The adhkar card with Western digits chosen no longer shows the surahs' Arabic-Indic ayah numbers (the ornament stays empty, as a Western digit would fall outside the circle).
- The screen stays on (only while shown) on the phone-control pairing screen and its «سماح/رفض» prompt, the update screens and «إعداد تلفزيوني», so the screensaver no longer closes them.
- Typing from the phone into YouTube TV (no text field to Android) opens YouTube's own search with the words; where an app has none, the phone page says so. The log (`UrTVType`) now adds the focused node's class name when no field is found.
- Cards saved from the phone (setting the first one back to «بدون» too) reach the home screen in front at once; the TV now asks the screensaver what it holds after the save and tells the phone if it is not what was sent.
- Typing into YouTube TV: its search opens first, on any of its screens (the first version asked Android if the app could be reached, which Android 11+ answers «no» for other apps).
- «حماية العائلة (DNS)»: the first check waits for Private DNS and retries a fresh name (up to 40 s), so a working TV is no longer turned down.
- The adhkar card shows a dhikr at night too (the evening ones when there is no night verse), never only a start time.

**Prayer times and adhan**
- Gulf cities, each country's own prayer method, and Ja'fari. Oman uses its Ministry of Awqaf's method (Fajr and Isha 18°, Dhuhr, Asr and Maghrib +5 minutes, from egyjs/afnon-android-tv-launcher, MIT); the Gulf method stays as «طريقة الحساب» ← الخليج.
- «تعديل وقت الصلاة»: move each prayer by its own minutes.
- The adhan bar names the prayer before the adhan; the Fajr voice and a short adhan; honest buffering.
- The adhan keeps its right time through previews and city changes; the TV's volume comes back after any adhan.
- «أذان من ملفي»: the person's own adhan; the old one stays until the new one is in.

**Home screen and screensaver**
- Settings › «شاشة التوقف» › «نظام الساعة»: «١٢ ساعة» or «٢٤ ساعة», the same setting as `saver.sh clock24`; the screensaver, the home's clock and cards and «تلاوة وأذان» follow it.
- The lists of choices with «حفظ» in the settings («الدوريات كاملة», «الفرق المتابعة», «التصنيفات», «اللغات», «رياضات أخرى», «الأسواق», «مسلسلات مختارة») keep «حفظ» on the screen: the list scrolls in a capped height, ▼ on its last row reaches «حفظ», and Back saves too (a user could not save «الدوريات كاملة» on a TV).
- «مركز التحكم» has «انعكاس الشاشة» when the TV has a screen-mirroring app (TCL's «عرض الشاشة» first), with «من الجوال: شارك الشاشة واختر التلفزيون» under it; with nine tiles the panel may go five to a row.
- Network only while the home is in front and the display is on (weather, hosted photos, Aladhan's times, adhan recordings, the update check); the adhan itself is unchanged. The audit is `docs/NETWORK.md`.
- The «المصادر» list shows the name an HDMI-CEC device gives itself (console, box) instead of «HDMI 2», and « · وضع الاستعداد» when the input is in standby; your own name still wins; `dock.sh input-names` shows both.
- «جرس التحديثات»: a bell in the home screen's top row that shows only on evidence of waiting Play Store updates (none can be read with normal permissions yet, so it stays out of sight), a setting and `saver.sh updatebell`.
- «تعديل المفضلة»: press a favourite to pick it up and move it along the row, × to remove it with «تراجع»; «ترتيب التطبيقات المفضلة» is now in the settings only.
- The glass look (د) on every screen of ours: settings, tasks, phone control and pairing, parental and the PIN, update, «إعداد تلفزيوني», «مركز التحكم», Family protection, the «تلاوة وأذان» screens and the phone page. Smoked glass in dark, frosted white in light, over the home's photo blurred once per photo (no live blur); each photo gets the veil its texts need to read.
- «المظهر» is the first row of the home screen's settings: «الشكل» (زجاجي، فحمي، كحلي، نظيف) for every screen of ours, and «الإضاءة» (داكن، فاتح، تلقائي), each choice previewed live before it is picked; `saver.sh look`.
- From the TV test (build 147): «أكمل المشاهدة» is a row of favourite-sized cards under the favourites again (it could come before them and fill the screen); a focused row in the settings has dark ink on its white fill; the settings never move sideways; the pickers are opaque; the «إعدادات تلفزيونك» tile has its icon.
- «تعديل التطبيقات»: «كل التطبيقات» in your own order (pick up and move across the grid), × to hide an app with «تراجع», «المخفية» to bring one back, ▲ from the first row into the favourites; «ترتيب كل التطبيقات» in the settings, with «رجوع للترتيب الأصلي». Not in kids mode, and neither is «تعديل المفضلة» now.
- Prayer times as boxes, new pills (icons only, the name shows on focus), glass panels, softer glow on the focused app.
- «يُتلى الآن» card while تلاوة plays; the screen is now «تلاوة وأذان».
- A year strip under the clock, the date beside the clubs, club crests when fetch is refused, fixes to the league card.
- The screensaver starts from its pill; the page survives a WebView renderer that dies.
- «مركز التحكم»: one round pill opens a panel of tiles (sleep timer, turn off now, network, speed test, sound output, screensaver, our settings, the TV's settings); the sleep, screensaver, Wi-Fi and settings pills moved into it, locked by the same names, plus a new lock `@center`.
- «مركز التحكم»: all tiles fit on 1080p and 720p, it opens on the tile used last, the sound output tile names the real output, «أطفئ الآن» says first when the sleep service is off, a new «إعدادات تلفزيونك» tile (locked by `@urtv`); «حرّر الذاكرة» is gone (no use on Android 14). The remote's Settings key now opens our settings.
- The weather and the dust are told apart; forecast and weather show only as old as they are; the last price is kept and marked.
- The medium and small clocks lay the screen out again (the large one is unchanged); «بطاقة ثانية»: a second card beside the small clock.

**Speed and safety**
- Fetches and the live poll stay inside their deadlines; apps load off the UI thread; downloads are capped.
- The Unsplash key goes only to the Unsplash API.
- App caches are trimmed only when storage is low.
- Install no longer dies on a silent TV; the sleep timer is forgotten on restart; the stock home comes back at once if ours does not open.
- Android's own core packages are never disabled; reset puts back the values the backup recorded.

**Setup and tools**
- The home switch can always be undone: a nonce on the safety switch, a heartbeat check before switching, a journal read on the next run, and `optimize/restore-home.sh`.
- Pair over Wireless debugging, find the TV again, and check first that it is Android TV with a new enough WebView.
- Community lists for TVs our own lists do not know; the setup wizard and TCL auto-start are handled.
- The setup shows what was turned off and lets a person keep any of it.
- Problems are reported through the form, never GitHub; share steps never print a negative time; Windows 11 is told from 10.
- The ADB key and the saved TV stay outside the clone.
- `AGENTS.md` for agents; new rows for the `!!` lines; the models seen in reports in `docs/TVS.md`.
- Reports keep only the lines the script builds, and the scrub (the net for what the scripts printed on `!!` lines)
  also covers IPv6 addresses, emails, serials, tokens, links with tokens, Wi-Fi names and user names.
- `SECURITY.md`, `CONTRIBUTING.md` and this file.
- «تحكم من الجوال»: a much better page (a swipe pad, volume, an Arabic text field, the favourites with their real icons, what plays, the sleep timer and screensaver, a read-only family card) and the endpoints behind it; locked apps ask for the PIN on the TV; Back works over other apps with the accessibility service.
- For testing only: `optimize/saver.sh updatechannel next` makes «تحديث تلفزيوني» read the apk-next build (the CI now publishes its `version.txt`); `tests/android_compile.sh` compiles both apps against API 34 (SKIP when offline) and runs in `tests/run.sh`. It also fails on a source that uses a class hidden in the public SDK (`tests/hidden_api_scan.py`; that is what broke the release build once), and uses the real public `android.jar` when the Android SDK is installed.

**Thanks (GitHub handles, with the issue or pull request number):**
- Brent oil in the markets bar: hak151617-sys (#39).
- The 24-hour clock «ساعة ٢٤»: saadabdelhafid-cyber (#41).
- The Jordan prayer method: alaaalquda-hub (#34). Egypt's method and cities are in too.
- The fix for the older WebView (66) that stopped the page's JavaScript: ayhankaraalitr-eng posted it first (#21), ckpb4fjvs7-ops sent the same fix again (#43), and omarghxd-art reported the problem (#19).
- The sunrise after Fajr, the bar of the time between two prayers and the humidity and wind: beeshooo2010-jpg (#28).
- The audio-focus fix (the Quran and the adhan no longer stutter or fight other sound): itsAbdulelah (#35); the TV updating itself, earlier: itsAbdulelah (#10).
- The PIN and kids mode («حماية العائلة»): AbdullahCg (#40).
- Club crests: samiharthy (#30).
- NBA and NFL teams and the F1 weekend sessions: iiMihyar (#8); we rebuilt them on TheSportsDB, but the idea and the first version were his.
- Club badges on the match cards: al3omdh22 (#13) sent them first.
- The remote's app buttons «أزرار الريموت»: 7odaifa-ab (#59).

## 23 October 2026 (51b9680)

Release: everything tested on `next` up to that day became the release.
